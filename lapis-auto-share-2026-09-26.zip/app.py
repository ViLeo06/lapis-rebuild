"""佣兵传说练级工具（试用版）的中文单窗口 UI。

默认只显示 Stopped 状态，不捕获屏幕、不创建 Bridge session、不发送输入。
只有用户依次选择窗口、完成三点校准并点击开始后，当前前台游戏才会进入闭环。
"""

from __future__ import annotations

import argparse
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import shutil
import tempfile
import threading
import time
from concurrent.futures import Future, ThreadPoolExecutor
from typing import Any, Optional
import tkinter as tk
from tkinter import messagebox, ttk

try:
    from .diagnostics import DiagnosticsRecorder
    from .engine import Action, Controller, ControllerState, LoopConfig, Observation, Positions, Scene
    from .vision import Vision, replay_directory
except ImportError:  # 由 launch.py/runpy(app.py) 启动时使用
    from diagnostics import DiagnosticsRecorder
    from engine import Action, Controller, ControllerState, LoopConfig, Observation, Positions, Scene
    from vision import Vision, replay_directory


BASE_DIR = Path(__file__).resolve().parent
PROFILE_PATH = BASE_DIR / "profile.json"
LOG_DIR = BASE_DIR / "logs"
ASSETS_DIR = BASE_DIR / "assets"
SAMPLE_MS = 180
OBSERVATION_WINDOW_SECONDS = 1.5
DIAGNOSTIC_SNAPSHOT_SECONDS = 10 * 60


def _logger() -> logging.Logger:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("lapis-auto")
    if not logger.handlers:
        handler = RotatingFileHandler(
            LOG_DIR / "lapis-auto.log",
            maxBytes=10 * 1024 * 1024,
            backupCount=10,
            encoding="utf-8",
            delay=True,
        )
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger


LOGGER = _logger()


def _atomic_write_json(path: Path, data: dict[str, Any]) -> None:
    """在本目录内原子更新配置，并保留一份可回滚备份。"""

    path = path.resolve()
    if path.parent != BASE_DIR:
        raise ValueError("配置文件必须位于工具目录")
    if path.exists():
        shutil.copy2(path, path.with_suffix(path.suffix + ".bak"))
    fd, temp_name = tempfile.mkstemp(prefix=".profile-", suffix=".tmp", dir=str(BASE_DIR), text=True)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(data, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def _safe_profile() -> dict[str, Any]:
    if not PROFILE_PATH.is_file():
        return {}
    try:
        payload = json.loads(PROFILE_PATH.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        LOGGER.warning("profile.json 无法读取，需重新校准")
        return {}
    if not isinstance(payload, dict) or payload.get("version") != 1:
        return {}
    return payload


class LapisApp:
    def __init__(self, root: tk.Tk, base_dir: Path = BASE_DIR):
        self.root = root
        self.base_dir = base_dir.resolve()
        self.root.title("佣兵传说练级工具（试用版）")
        self.root.geometry("760x700")
        self.root.minsize(680, 620)
        self.root.protocol("WM_DELETE_WINDOW", self.close)

        self.bridge: Any | None = None
        self.hotkey_ready = False
        self.bound: dict[str, Any] | None = None
        self.vision: Vision | None = None
        self.profile = _safe_profile()
        self.positions: Positions | None = None
        self.controller: Controller | None = None
        self.running = False
        self.observing = False
        self.closed = False
        self._calibrating: str | None = None
        self._calibration_step = 0
        self._generation = 0
        self._future: Future[Any] | None = None
        self._future_action: Action | None = None
        self._future_generation: int | None = None
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="lapis-sender")
        self._frame_id = 0
        self._last_observation: Any | None = None
        self._started_at: float | None = None
        self._ui_countdown_callback: Any | None = None
        self._ui_countdown_step = 0
        self._ui_countdown_label = ""
        self._ui_countdown_epoch = 0
        self._calibration_epoch = 0
        self._diagnostics = DiagnosticsRecorder(
            self.base_dir / "logs",
            snapshot_interval_seconds=DIAGNOSTIC_SNAPSHOT_SECONDS,
            max_sessions=60,
        )
        self._last_frame: Any | None = None
        self._last_logged_scene: str | None = None

        self.status_var = tk.StringVar(value="已停止：尚未选择游戏窗口")
        self.scene_var = tk.StringVar(value="画面：未捕获")
        self.health_var = tk.StringVar(value="血蓝：未捕获")
        self.count_var = tk.StringVar(value="已确认场次：0")
        self.time_var = tk.StringVar(value="运行时间：00:00")
        self.reason_var = tk.StringVar(value="安全提示：默认不捕获、不发送输入；死亡/复活未接入")
        self.window_var = tk.StringVar(value="窗口：未绑定")
        self.observe_var = tk.StringVar(value="只观察")
        self._build_ui()
        self.root.after(250, self._poll)

    def _build_ui(self) -> None:
        outer = ttk.Frame(self.root, padding=14)
        outer.pack(fill="both", expand=True)

        ttk.Label(outer, text="佣兵传说练级工具（试用版）", font=("Microsoft YaHei UI", 15, "bold")).pack(
            anchor="w"
        )
        ttk.Label(outer, text="窗口位置可移动 · 客户区尺寸保持不变 · 本地识别 · 默认停止", foreground="#555").pack(anchor="w", pady=(2, 10))

        status = ttk.LabelFrame(outer, text="当前状态", padding=10)
        status.pack(fill="x")
        for var in (self.status_var, self.window_var, self.scene_var, self.health_var, self.count_var, self.time_var):
            ttk.Label(status, textvariable=var).pack(anchor="w", pady=1)

        controls = ttk.LabelFrame(outer, text="第一步：选择并校准", padding=10)
        controls.pack(fill="x", pady=(10, 0))
        row = ttk.Frame(controls)
        row.pack(fill="x")
        self.select_button = ttk.Button(row, text="选择游戏窗口", command=self.select_game)
        self.select_button.pack(side="left", padx=(0, 6))
        self.calibration_buttons: dict[str, ttk.Button] = {}
        for key, text in (("foot", "校准人物脚下格子"), ("red", "校准红药位置"), ("blue", "校准蓝药位置")):
            button = ttk.Button(row, text=text, command=lambda k=key: self.calibrate(k), state="disabled")
            button.pack(side="left", padx=3)
            self.calibration_buttons[key] = button
        self.calibration_hint = ttk.Label(
            controls,
            text="施毒点必须在战斗中校准：把鼠标放到自己角色脚下的地面格子（不是技能按钮）。红/蓝药按物品位置校准。",
            foreground="#555",
            wraplength=680,
        )
        self.calibration_hint.pack(anchor="w", pady=(7, 0))

        run = ttk.LabelFrame(outer, text="第二步：运行控制", padding=10)
        run.pack(fill="x", pady=(10, 0))
        row2 = ttk.Frame(run)
        row2.pack(fill="x")
        ttk.Button(row2, textvariable=self.observe_var, command=self.toggle_observe).pack(side="left", padx=(0, 6))
        self.trial_button = ttk.Button(row2, text="开始3场试跑", command=lambda: self.start(3), state="disabled")
        self.trial_button.pack(side="left", padx=3)
        self.loop_button = ttk.Button(row2, text="开始循环", command=lambda: self.start(None), state="disabled")
        self.loop_button.pack(side="left", padx=3)
        self.pause_button = ttk.Button(row2, text="暂停", command=self._toggle_pause, state="disabled")
        self.pause_button.pack(side="left", padx=3)
        self.stop_button = ttk.Button(row2, text="停止", command=lambda: self.stop("用户停止"), state="disabled")
        self.stop_button.pack(side="left", padx=3)
        ttk.Label(run, text="连续循环最长运行 24 小时；可随时按 F8 或“停止”结束。", foreground="#555").pack(
            anchor="w", pady=(7, 0)
        )

        notice = ttk.LabelFrame(outer, text="安全边界", padding=10)
        notice.pack(fill="both", expand=True, pady=(10, 0))
        ttk.Label(
            notice,
            text=(
                "只观察画面，不按键、不点击。\n"
                "窗口可左右移动；不要改变客户区尺寸。实际点击点不能被其他窗口挡住；F8 是全局急停。\n"
                "血蓝数值是 HUD 视觉估计，仅供显示，不再参与停机或战斗触发判断。\n"
                "录像没有可靠死亡模板，本版遇异常会停机，不自动使用复活药水。"
            ),
            justify="left",
        ).pack(anchor="w")
        ttk.Label(outer, textvariable=self.reason_var, foreground="#8a4b00", wraplength=650).pack(anchor="w", pady=(8, 0))
        self.root.update_idletasks()
        # 高 DPI 下按控件实际需求扩大窗口，避免安全边界和 F8 提示被裁掉。
        req_w = max(760, self.root.winfo_reqwidth() + 24)
        req_h = max(700, self.root.winfo_reqheight() + 24)
        screen_w = self.root.winfo_screenwidth()
        screen_h = self.root.winfo_screenheight()
        self.root.geometry(f"{min(req_w, max(680, screen_w - 80))}x{min(req_h, max(620, screen_h - 80))}")

    def _ensure_bridge(self) -> Any | None:
        if self.bridge is not None:
            return self.bridge
        try:
            from winbridge import Bridge

            self.bridge = Bridge(self.base_dir)
            try:
                self.bridge.install_hotkey(self._emergency_stop)
                self.hotkey_ready = True
            except Exception as exc:
                LOGGER.warning("F8 热键安装失败：%s", exc)
                self.hotkey_ready = False
                self.reason_var.set("安全提示：F8 热键安装失败，请保留窗口中的停止按钮")
            return self.bridge
        except Exception as exc:
            LOGGER.warning("无法创建本地 Bridge：%s", exc)
            self._show_error("无法启动本地桥接", str(exc))
            return None

    def select_game(self) -> None:
        if self.running or self.observing:
            self.stop("重新选择窗口前已停止当前会话")
        bridge = self._ensure_bridge()
        if bridge is None:
            return
        # 选择窗口只做只读识别，不需要切回游戏等待倒计时。
        self._select_game_now()

    def _select_game_now(self) -> None:
        bridge = self.bridge
        if bridge is None:
            return
        try:
            info = bridge.select_game()
            bridge.bind(info)
            self.bound = dict(info)
            self.vision = Vision(self.base_dir / "assets")
            self._load_profile_for_bound()
            self.window_var.set(f"窗口：已绑定 {info.get('width')}×{info.get('height')}，PID {info.get('pid')}")
            self.status_var.set("已停止：窗口已绑定，请完成三点校准")
            self.reason_var.set("安全提示：尚未开始，不会发送输入")
            self._refresh_buttons()
        except Exception as exc:
            LOGGER.warning("选择游戏窗口失败：%s", exc)
            self._show_error("选择游戏窗口失败", str(exc))

    def _load_profile_for_bound(self) -> None:
        self.positions = None
        if not self.bound or not isinstance(self.profile, dict):
            return
        if self.profile.get("width") != self.bound.get("width") or self.profile.get("height") != self.bound.get("height"):
            return
        coords = self.profile.get("coordinates")
        if not isinstance(coords, dict):
            return
        try:
            points: dict[str, tuple[int, int]] = {}
            for key in ("foot", "red", "blue"):
                value = coords[key]
                if not isinstance(value, list) or len(value) != 2 or any(isinstance(v, bool) or not isinstance(v, int) for v in value):
                    return
                points[key] = (int(value[0]), int(value[1]))
            candidate = Positions(points["foot"], points["red"], points["blue"], int(self.bound["width"]), int(self.bound["height"]))
            candidate.validate()
            self.positions = candidate
            self.reason_var.set(
                f"已加载校准：脚下格子 {candidate.foot[0]},{candidate.foot[1]}；"
                f"红药 {candidate.red[0]},{candidate.red[1]}；蓝药 {candidate.blue[0]},{candidate.blue[1]}"
            )
            if hasattr(self, "calibration_hint"):
                self.calibration_hint.configure(
                    text=(
                        f"已加载校准：脚下格子 {candidate.foot} · "
                        f"红药 {candidate.red} · 蓝药 {candidate.blue}"
                    )
                )
        except (KeyError, TypeError, ValueError):
            self.positions = None

    def calibrate(self, kind: str) -> None:
        if not self.bound or not self.bridge or self.running or self.observing:
            self.reason_var.set("请先选择游戏窗口，且在停止状态校准")
            return
        self._calibrating = kind
        self._calibration_step = 3
        self._calibration_epoch += 1
        calibration_epoch = self._calibration_epoch
        self._refresh_buttons()
        self._countdown_calibration(calibration_epoch)

    def _countdown_calibration(self, calibration_epoch: int | None = None) -> None:
        if calibration_epoch is None:
            calibration_epoch = self._calibration_epoch
        if self.closed or self._calibrating is None or calibration_epoch != self._calibration_epoch:
            return
        if self._calibration_step > 0:
            label = {"foot": "战斗中自己角色脚下的地面格子", "red": "红药位置", "blue": "蓝药位置"}[self._calibrating]
            self.calibration_hint.configure(text=f"请把鼠标放在{label}，{self._calibration_step} 秒后读取坐标；不会点击游戏。")
            self._calibration_step -= 1
            self.root.after(1000, lambda epoch=calibration_epoch: self._countdown_calibration(epoch))
            return
        try:
            point = self.bridge.get_client_cursor()
            width, height = int(self.bound["width"]), int(self.bound["height"])
            if not (0 <= point[0] < width and 0 <= point[1] < height):
                raise ValueError("鼠标不在游戏客户区")
            if self._calibrating == "foot":
                if self.vision is None:
                    raise ValueError("识别器尚未初始化")
                visual = self.vision.analyze(self.bridge.capture())
                if visual.scene != Scene.BATTLE:
                    raise ValueError("人物脚下格子必须在战斗画面中校准；请等进入战斗后再校准")
                # 防止误把底部技能/物品栏当成施毒目标。战斗角色通常位于中央战场。
                if not (
                    int(width * 0.18) <= point[0] <= int(width * 0.82)
                    and int(height * 0.12) <= point[1] <= int(height * 0.78)
                ):
                    raise ValueError("施毒坐标看起来落在 HUD/边缘区域；请把鼠标放到战斗中自己角色脚下的地面格子")
            current: dict[str, tuple[int, int] | None] = {"foot": None, "red": None, "blue": None}
            profile_matches = (
                isinstance(self.profile, dict)
                and self.profile.get("width") == self.bound.get("width")
                and self.profile.get("height") == self.bound.get("height")
            )
            saved = self.profile.get("coordinates") if profile_matches else None
            if isinstance(saved, dict):
                for key in current:
                    value = saved.get(key)
                    if isinstance(value, list) and len(value) == 2 and all(
                        isinstance(v, int) and not isinstance(v, bool) for v in value
                    ):
                        current[key] = (int(value[0]), int(value[1]))
            if self.positions:
                current.update({"foot": self.positions.foot, "red": self.positions.red, "blue": self.positions.blue})
            current[self._calibrating] = point
            if any(value is None for value in current.values()):
                self.positions = None
            else:
                self.positions = Positions(current["foot"], current["red"], current["blue"], width, height)  # type: ignore[arg-type]
                self.positions.validate()
            self.profile = {
                "version": 1,
                "width": width,
                "height": height,
                "coordinates": {key: list(value) for key, value in current.items() if value is not None},
            }
            _atomic_write_json(PROFILE_PATH, self.profile)
            saved_label = {"foot": "人物脚下施毒格子", "red": "红药", "blue": "蓝药"}[self._calibrating]
            self.calibration_hint.configure(
                text=f"{saved_label}坐标已保存：({point[0]}, {point[1]})；如需修正可再次校准。"
            )
            self.reason_var.set("安全提示：校准不会点击；三点齐全后才可开始")
        except Exception as exc:
            LOGGER.warning("校准失败：%s", exc)
            self._show_error("校准失败", str(exc))
        finally:
            self._calibrating = None
            self._refresh_buttons()

    def _ready_to_start(self) -> bool:
        if not self.bridge or not self.hotkey_ready or not self.bound or not self.vision:
            if self.bridge and not self.hotkey_ready:
                self.reason_var.set("F8 全局急停未安装，已禁止开始")
                return False
            self.reason_var.set("请先选择游戏窗口")
            return False
        if self.positions is None:
            self.reason_var.set("请先完成施毒、红药、蓝药三点校准")
            return False
        if self._future is not None:
            self.reason_var.set("上一条输入仍在收尾，请稍候再开始")
            return False
        return True

    def start(self, max_battles: int | None) -> None:
        if self.running or self.observing or not self._ready_to_start():
            return
        self._queue_ui_countdown(
            "开始试跑" if max_battles is not None else "开始循环",
            lambda: self._start_now(max_battles),
        )

    def _start_now(self, max_battles: int | None) -> None:
        if self.running or self.observing or not self._ready_to_start():
            return
        assert self.bridge is not None and self.vision is not None and self.positions is not None
        try:
            # 用户点击“开始”后工具本身会获得前台焦点。正式 session 前主动把
            # 已绑定游戏切回前台，避免用户在倒计时末尾抢焦点。
            self.bridge.activate_game()
            captured_at = time.monotonic()
            image = self.bridge.capture()
            captured_tick = self._captured_tick(image)
            if captured_tick is None:
                raise RuntimeError("截图缺少 Bridge captured_tick，拒绝建立 session")
            self._frame_id += 1
            visual = self.vision.analyze(image)
            observation_deadline = captured_at + OBSERVATION_WINDOW_SECONDS
            if time.monotonic() >= observation_deadline:
                raise RuntimeError("启动截图观察已过期，拒绝建立 session")
            initial = visual.to_engine(
                self._frame_id,
                observed_at=captured_at,
                observation_deadline=observation_deadline,
                observation_deadline_tick=captured_tick + int(OBSERVATION_WINDOW_SECONDS * 1000),
            )
            self.controller = Controller(
                self.positions,
                LoopConfig(
                    max_minutes=24 * 60,
                    max_battles=max_battles,
                    supply_gap=2.0,
                    tab_to_x_gap=0.25,
                    x_to_aim_gap=1.0,
                    aim_to_cast_gap=1.0,
                    retry_gap=8.0,
                    victory_timeout=20.0,
                    return_field_timeout=30.0,
                    unknown_timeout=8.0,
                ),
            )
            now = time.monotonic()
            if now >= observation_deadline:
                raise RuntimeError("启动截图观察在建立 session 前已过期，拒绝启动")
            self.controller.start(now, initial)
            self.bridge.begin_session()
            self._generation += 1
            self.running = True
            self._started_at = now
            self.observing = False
            self.status_var.set("运行中：输入已启用，等待安全动作")
            self.reason_var.set("健康值仅为视觉估计；每场必须胜利后回到野外才计数")
            self._last_observation = visual
            self._last_frame = image
            self._last_logged_scene = None
            self._diagnostic_start(max_battles, image, visual)
            self._refresh_buttons()
        except Exception as exc:
            LOGGER.warning("开始失败：%s", exc)
            if self.controller:
                self.controller.cancel("开始失败")
            try:
                self.bridge.cancel()
            except Exception:
                pass
            self._show_error("无法开始", str(exc))

    def _diagnostic_context(self, visual: Any | None = None) -> dict[str, Any]:
        visual = visual if visual is not None else getattr(self, "_last_observation", None)
        controller = getattr(self, "controller", None)
        scene = getattr(visual, "scene", None)
        if isinstance(scene, Scene):
            scene = scene.value
        state = getattr(controller, "state", None)
        if isinstance(state, ControllerState):
            state = state.value
        return {
            "frame_id": getattr(self, "_frame_id", 0),
            "scene": scene,
            "confidence": getattr(visual, "confidence", None),
            "hp_ratio": getattr(visual, "hp_ratio", None),
            "mp_ratio": getattr(visual, "mp_ratio", None),
            "scores": getattr(visual, "scores", None),
            "notes": getattr(visual, "notes", None),
            "controller_state": state,
            "controller_stop_reason": getattr(controller, "stop_reason", "") if controller else "",
            "battle_count": getattr(controller, "battle_count", 0) if controller else 0,
            "round_number": getattr(controller, "round_number", 0) if controller else 0,
            "current_action_reason": getattr(controller, "current_action_reason", "") if controller else "",
            "running": getattr(self, "running", False),
            "observing": getattr(self, "observing", False),
        }

    def _diagnostic_start(self, max_battles: int | None, image: Any, visual: Any) -> None:
        try:
            mode = f"trial-{max_battles}" if max_battles is not None else "loop"
            session_id = self._diagnostics.start_session(
                mode=mode,
                bound=self.bound,
                positions=self.positions,
                config=self.controller.config if self.controller else None,
                image=image,
                context=self._diagnostic_context(visual),
            )
            LOGGER.info("诊断会话开始：%s mode=%s", session_id, mode)
        except Exception as exc:
            LOGGER.warning("诊断会话启动失败（不影响运行）：%s", exc)

    def _diagnostic_scene(self, visual: Any) -> None:
        scene = visual.scene.value if isinstance(visual.scene, Scene) else str(visual.scene)
        previous = getattr(self, "_last_logged_scene", None)
        if scene == previous:
            return
        self._last_logged_scene = scene
        context = self._diagnostic_context(visual)
        LOGGER.info(
            "场景变化：%s -> %s conf=%.2f state=%s battles=%s",
            previous or "none",
            scene,
            float(getattr(visual, "confidence", 0.0) or 0.0),
            context.get("controller_state"),
            context.get("battle_count"),
        )
        try:
            self._diagnostics.record_event(
                "scene_change",
                previous_scene=previous,
                new_scene=scene,
                context=context,
            )
        except Exception as exc:
            LOGGER.warning("诊断场景记录失败（不影响运行）：%s", exc)

    def _diagnostic_periodic(self, image: Any, visual: Any) -> None:
        try:
            path = self._diagnostics.maybe_periodic_snapshot(
                image,
                context=self._diagnostic_context(visual),
            )
            if path is not None:
                LOGGER.info("定时诊断截图：%s", path)
        except Exception as exc:
            LOGGER.warning("定时诊断截图失败（不影响运行）：%s", exc)

    def _diagnostic_event(self, event: str, **data: Any) -> None:
        try:
            self._diagnostics.record_event(event, **data)
        except Exception as exc:
            LOGGER.warning("诊断事件记录失败（不影响运行）：%s", exc)

    @staticmethod
    def _is_abnormal_stop(reason: str) -> bool:
        normal_exact = {
            "用户停止",
            "F8 全局急停",
            "关闭窗口",
            "重新选择窗口前已停止当前会话",
            "达到最长运行时间",
        }
        if reason in normal_exact:
            return False
        if reason.startswith("已完成 ") and "场试跑" in reason:
            return False
        if reason.startswith("已暂停"):
            return False
        return True

    def _diagnostic_stop(self, reason: str) -> None:
        try:
            abnormal = self._is_abnormal_stop(reason)
            context = self._diagnostic_context()
            diagnostics = getattr(self, "_diagnostics", None)
            if diagnostics is None:
                return
            diagnostics.stop_session(
                reason,
                image=getattr(self, "_last_frame", None),
                context=context,
                abnormal=abnormal,
            )
            LOGGER.info(
                "诊断会话结束：reason=%s abnormal=%s state=%s battles=%s",
                reason,
                abnormal,
                context.get("controller_state"),
                context.get("battle_count"),
            )
        except Exception as exc:
            LOGGER.warning("诊断会话收尾失败（不影响停机）：%s", exc)

    def _toggle_pause(self) -> None:
        if self.controller and self.controller.paused:
            self.resume()
        else:
            self.pause()

    def pause(self) -> None:
        if not self.running or not self.controller or not self.bridge:
            return
        self._generation += 1
        self._diagnostic_stop("已暂停；请重新开始新的 session")
        self.controller.pause(time.monotonic())
        try:
            self.bridge.cancel()
        except Exception as exc:
            LOGGER.warning("暂停时取消 session 失败：%s", exc)
        self.running = False
        self.status_var.set("已暂停：输入 session 已失效")
        self.reason_var.set("暂停会让当前旧指令失效；请点击开始按钮建立新的 session")
        self._refresh_buttons()

    def resume(self) -> None:
        # 暂停后的旧战斗上下文不恢复，避免跨代动作；用户点击开始按钮即可新建 session。
        self.reason_var.set("暂停后的战斗上下文已清除，请点击开始3场试跑或开始循环")

    def stop(self, reason: str = "用户停止") -> None:
        self._generation += 1
        self._ui_countdown_epoch = getattr(self, "_ui_countdown_epoch", 0) + 1
        self._calibration_epoch = getattr(self, "_calibration_epoch", 0) + 1
        # 失效所有尚未执行的 UI 回调；root.after 仍会触发，但回调看到 None 后立即返回。
        self._ui_countdown_callback = None
        self._ui_countdown_step = 0
        self._ui_countdown_label = ""
        self._calibrating = None
        self._calibration_step = 0
        self._diagnostic_stop(reason)
        self.running = False
        self.observing = False
        if self.controller:
            self.controller.cancel(reason)
        if self.bridge:
            try:
                self.bridge.cancel()
            except Exception as exc:
                LOGGER.warning("停止时取消 session 失败：%s", exc)
        self.status_var.set(f"已停止：{reason}")
        self.reason_var.set("安全提示：当前 session 已失效；重新开始会生成新 token")
        self._refresh_buttons()

    def _emergency_stop(self) -> None:
        self.stop("F8 全局急停")

    def toggle_observe(self) -> None:
        if self.observing:
            self.observing = False
            self.status_var.set("已停止：纯观察已关闭")
            self.observe_var.set("只观察")
            self._refresh_buttons()
            return
        if self.running or not self.bridge or not self.bound or not self.vision:
            self.reason_var.set("只观察也需要先选择游戏窗口；运行中请先停止")
            return
        self._queue_ui_countdown("开始只观察", self._start_observe_now)

    def _start_observe_now(self) -> None:
        if self.running or not self.bridge or not self.bound or not self.vision:
            return
        self.observing = True
        self.observe_var.set("停止只观察")
        self.status_var.set("只观察中：只截图/识别，不发送输入")
        self.reason_var.set("只观察结果是视觉估计，不代表动作成功或补给已生效")
        self._refresh_buttons()

    def _queue_ui_countdown(self, label: str, callback: Any, seconds: int = 3) -> None:
        if self.closed or self._ui_countdown_callback is not None:
            return
        self._ui_countdown_epoch += 1
        countdown_epoch = self._ui_countdown_epoch
        self._ui_countdown_callback = callback
        self._ui_countdown_label = label
        self._ui_countdown_step = seconds
        self._refresh_buttons()
        self._run_ui_countdown(countdown_epoch)

    def _run_ui_countdown(self, countdown_epoch: int | None = None) -> None:
        if countdown_epoch is None:
            countdown_epoch = self._ui_countdown_epoch
        if self.closed or self._ui_countdown_callback is None or countdown_epoch != self._ui_countdown_epoch:
            return
        if self._ui_countdown_step > 0:
            self.status_var.set(f"{self._ui_countdown_label}：{self._ui_countdown_step} 秒后执行，请保持游戏窗口可见")
            self._ui_countdown_step -= 1
            self.root.after(1000, lambda epoch=countdown_epoch: self._run_ui_countdown(epoch))
            return
        callback = self._ui_countdown_callback
        if self.bridge is not None:
            try:
                # F8 由工作线程先取消 session，再把事件交给 UI；在执行任何排队动作前主动消费它。
                self.bridge.poll_hotkey()
            except Exception as exc:
                LOGGER.warning("倒计时结束时 F8 检查失败，已取消待执行操作：%s", exc)
                self._ui_countdown_epoch += 1
                self._ui_countdown_callback = None
                self._ui_countdown_step = 0
                self._ui_countdown_label = ""
                self.reason_var.set("安全提示：F8 状态检查失败，已取消待执行操作")
                self._refresh_buttons()
                return
        if self.closed or self._ui_countdown_callback is not callback or countdown_epoch != self._ui_countdown_epoch:
            return
        self._ui_countdown_callback = None
        self._ui_countdown_label = ""
        callback()

    def _poll(self) -> None:
        if self.closed:
            return
        try:
            if self.bridge is not None:
                self.bridge.poll_hotkey()
        except Exception as exc:
            LOGGER.warning("F8 轮询失败：%s", exc)
        if self.observing or self.running:
            self._sample()
        self._update_elapsed()
        self.root.after(SAMPLE_MS, self._poll)

    def _sample(self) -> None:
        if not self.bridge or not self.vision:
            return
        try:
            # 从截图请求前开始计时；OBSERVATION_WINDOW_SECONDS 已放宽，
            # 同时 Bridge 会在截图完成时记录 captured_tick 供发送端二次校验。
            captured_at = time.monotonic()
            image = self.bridge.capture()
            self._last_frame = image
            self._frame_id += 1
            visual = self.vision.analyze(image)
            self._last_observation = visual
            self._show_visual(visual)
            self._diagnostic_scene(visual)
            self._diagnostic_periodic(image, visual)
            if self.observing and not self.running:
                return
            if not self.running or not self.controller:
                return
            captured_tick = self._captured_tick(image)
            if captured_tick is None:
                raise RuntimeError("截图缺少 Bridge captured_tick，安全停机")
            observation_deadline = captured_at + OBSERVATION_WINDOW_SECONDS
            observation = visual.to_engine(
                self._frame_id,
                observed_at=captured_at,
                observation_deadline=observation_deadline,
                observation_deadline_tick=captured_tick + int(OBSERVATION_WINDOW_SECONDS * 1000),
            )
            action = self.controller.tick(observation, time.monotonic())
            if action is not None:
                if action.kind == "left":
                    self.controller.note_click_mp(observation.mp_ratio)
                self._dispatch(action, self._generation)
            self._finish_if_stopped()
        except Exception as exc:
            LOGGER.warning("采样/识别失败：%s", exc)
            self._diagnostic_event(
                "sample_error",
                error=str(exc),
                context=self._diagnostic_context(),
            )
            if self.running:
                self.stop("截图或识别失败，安全停机")
                self._save_abnormal(image if "image" in locals() else None)
            else:
                self.scene_var.set("画面：采样失败（未发送输入）")
                self.reason_var.set(f"只观察失败：{exc}")

    @staticmethod
    def _captured_tick(image: Any) -> int | None:
        try:
            raw_tick = image.info.get("captured_tick")
        except Exception:
            return None
        if isinstance(raw_tick, int) and not isinstance(raw_tick, bool) and raw_tick >= 0:
            return raw_tick
        return None

    def _dispatch(self, action: Action, generation: int) -> None:
        if self._future is not None:
            self.stop("输入队列出现未完成动作，安全停机")
            return
        if not self.running or generation != self._generation or not self.bridge:
            return
        bridge = self.bridge
        self.status_var.set(f"运行中：准备执行 → {action.reason or action.kind}")
        self._diagnostic_event(
            "action_offered",
            action={
                "kind": action.kind,
                "point": action.point,
                "reason": action.reason,
                "sequence": action.sequence,
            },
            context=self._diagnostic_context(),
        )
        self._future_action = action
        self._future_generation = generation
        self._future = self._executor.submit(self._send_worker, bridge, action, generation)
        future = self._future
        def done_callback(done: Future[Any], f: Future[Any] = future) -> None:
            try:
                self.root.after(0, lambda: self._handle_send(f, done))
            except tk.TclError:
                return

        future.add_done_callback(done_callback)

    def _send_worker(self, bridge: Any, action: Action, generation: int) -> tuple[bool, str, int]:
        if generation != self._generation or not self.running:
            return False, "旧 session 动作已丢弃", generation
        if action.observation_deadline is None or time.monotonic() >= action.observation_deadline:
            return False, "截图观察已过期，拒绝发送", generation
        if action.observation_deadline_tick is None:
            return False, "Bridge 未提供截图时间戳，拒绝发送", generation
        try:
            bridge.send(
                action.kind,
                action.point,
                observation_deadline_tick=action.observation_deadline_tick,
            )
            return True, "", generation
        except Exception as exc:
            return False, str(exc), generation

    def _handle_send(self, future: Future[Any], done: Future[Any]) -> None:
        if self.closed:
            return
        if self._future is future:
            self._future = None
        try:
            success, error, generation = done.result()
        except Exception as exc:
            success, error, generation = False, str(exc), -1
        action = self._future_action
        self._future_action = None
        self._future_generation = None
        if action is None or generation != self._generation or not self.controller or not self.running:
            return
        self.controller.ack(action, success, time.monotonic())
        self._diagnostic_event(
            "action_result",
            success=success,
            error=error,
            action={
                "kind": action.kind,
                "point": action.point,
                "reason": action.reason,
                "sequence": action.sequence,
            },
            context=self._diagnostic_context(),
        )
        if not success:
            LOGGER.warning("输入未确认：%s", error)
            self.stop("输入未成功确认，安全停机")
        else:
            self.status_var.set(f"运行中：已发送 → {action.reason or action.kind}")
            LOGGER.info("输入已确认：%s", action.reason or action.kind)
        self._finish_if_stopped()

    def _finish_if_stopped(self) -> None:
        if self.running and self.controller and not self.controller.running:
            reason = self.controller.stop_reason or "状态机停止"
            self.stop(reason)

    def _show_visual(self, visual: Any) -> None:
        scene = visual.scene if isinstance(visual.scene, Scene) else Scene.UNKNOWN
        scene_cn = {Scene.FIELD: "野外", Scene.BATTLE: "战斗", Scene.VICTORY: "胜利", Scene.INVENTORY: "背包", Scene.UNKNOWN: "未知"}[scene]
        self.scene_var.set(f"画面：{scene_cn}（置信度 {visual.confidence:.2f}）")
        if visual.hp_ratio is None or visual.mp_ratio is None:
            self.health_var.set("血蓝：不可解释/待核验")
        else:
            self.health_var.set(
                f"血蓝估计：HP {visual.hp_ratio:.0%} · MP {visual.mp_ratio:.0%}（仅显示，不参与控制）"
            )
        if self.controller:
            self.count_var.set(f"已确认场次：{self.controller.battle_count}")
        if visual.notes:
            self.reason_var.set("；".join(visual.notes))

    def _update_elapsed(self) -> None:
        if self._started_at is None:
            return
        seconds = max(0, int(time.monotonic() - self._started_at))
        self.time_var.set(f"运行时间：{seconds // 60:02d}:{seconds % 60:02d}")

    def _save_abnormal(self, image: Any | None) -> None:
        if image is None:
            return
        try:
            stamp = time.strftime("%Y%m%d-%H%M%S")
            path = LOG_DIR / f"abnormal-{stamp}.png"
            image.save(path)
            LOGGER.info("已保存异常游戏 client 截图：%s", path.name)
        except Exception as exc:
            LOGGER.warning("异常截图保存失败：%s", exc)

    def _refresh_buttons(self) -> None:
        bound = self.bound is not None and self.bridge is not None
        ui_busy = self._ui_countdown_callback is not None or self._calibrating is not None
        state = "normal" if bound and not self.running and not self.observing and not ui_busy else "disabled"
        for button in self.calibration_buttons.values():
            button.configure(state=state)
        ready = bound and self.positions is not None and not self.running and not self.observing and not ui_busy
        self.trial_button.configure(state="normal" if ready else "disabled")
        self.loop_button.configure(state="normal" if ready else "disabled")
        self.pause_button.configure(state="normal" if self.controller and self.controller.paused else ("normal" if self.running else "disabled"))
        self.stop_button.configure(
            state="normal" if self.running or self.observing or ui_busy else "disabled"
        )

    def _show_error(self, title: str, detail: str) -> None:
        self.reason_var.set(f"{title}：{detail}")
        try:
            messagebox.showerror(title, detail, parent=self.root)
        except tk.TclError:
            pass

    def close(self) -> None:
        if self.closed:
            return
        self.closed = True
        self._generation += 1
        self._ui_countdown_epoch += 1
        self._calibration_epoch += 1
        self._ui_countdown_callback = None
        self._ui_countdown_step = 0
        self._ui_countdown_label = ""
        self._calibrating = None
        self._calibration_step = 0
        self._diagnostic_stop("关闭窗口")
        self.running = False
        self.observing = False
        if self.controller:
            self.controller.cancel("关闭窗口")
        if self.bridge:
            try:
                self.bridge.cancel()
            except Exception:
                pass
            try:
                self.bridge.close()
            except Exception as exc:
                LOGGER.warning("关闭 Bridge 失败：%s", exc)
        self._executor.shutdown(wait=False, cancel_futures=True)
        self.root.destroy()


def run_replay(path: str | Path) -> int:
    """只读录像回放入口；不创建 Bridge、不捕获当前桌面、不发送输入。"""

    vision = Vision(ASSETS_DIR)
    results = replay_directory(vision, path)
    for index, result in enumerate(results):
        print(json.dumps({"index": index, "scene": result.scene.value, "confidence": result.confidence, "notes": result.notes}, ensure_ascii=False))
    return 0


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="佣兵传说本地练级工具")
    parser.add_argument("--replay", help="只读回放 PNG 目录，不启动 GUI/Bridge")
    args = parser.parse_args(argv)
    if args.replay:
        return run_replay(args.replay)
    root = tk.Tk()
    LapisApp(root)
    root.mainloop()
    return 0


if __name__ == "__main__":  # import app.py 不创建窗口、不捕获、不发送
    raise SystemExit(main())
