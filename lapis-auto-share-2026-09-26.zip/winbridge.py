"""Fail-closed Win32 bridge for the local Lapis automation controller.

This module intentionally exposes only a very small surface:

* identify and bind the one visible ``佣兵传说`` / ``NeoDark.exe`` window;
* capture the unobscured client rectangle;
* return the cursor in client coordinates;
* invoke one of three explicitly allowed actions through ``sender.ahk``;
* register F8 as a thread hotkey for an emergency stop.

The bridge never activates a window and never sends input itself.  The AHK
helper performs the final, just-before-input validation as a second safety
boundary.
"""

from __future__ import annotations

import configparser
import ctypes
import hashlib
import json
import os
from pathlib import Path
import queue
import secrets
import subprocess
import sys
import tempfile
import threading
import time
from typing import Any, Callable, Iterable

from PIL import Image, ImageGrab


class BridgeError(RuntimeError):
    """A safety or environment check prevented an operation."""


class _POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


class _RECT(ctypes.Structure):
    _fields_ = [
        ("left", ctypes.c_long),
        ("top", ctypes.c_long),
        ("right", ctypes.c_long),
        ("bottom", ctypes.c_long),
    ]


class _MONITORINFO(ctypes.Structure):
    _fields_ = [
        ("cbSize", ctypes.c_ulong),
        ("rcMonitor", _RECT),
        ("rcWork", _RECT),
        ("dwFlags", ctypes.c_ulong),
    ]


class _MSG(ctypes.Structure):
    _fields_ = [
        ("hwnd", ctypes.c_void_p),
        ("message", ctypes.c_uint),
        ("wParam", ctypes.c_size_t),
        ("lParam", ctypes.c_ssize_t),
        ("time", ctypes.c_uint),
        ("pt", _POINT),
        ("lPrivate", ctypes.c_uint),
    ]


_IS_WINDOWS = sys.platform == "win32"
_user32: Any | None = None
_kernel32: Any | None = None
_shcore: Any | None = None
_dwmapi: Any | None = None
if _IS_WINDOWS:
    try:
        _user32 = ctypes.WinDLL("user32", use_last_error=True)
        _kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        try:
            _shcore = ctypes.WinDLL("shcore", use_last_error=True)
        except OSError:
            _shcore = None
        try:
            _dwmapi = ctypes.WinDLL("dwmapi", use_last_error=True)
        except OSError:
            _dwmapi = None
    except OSError as exc:  # pragma: no cover - only possible on a broken host
        raise BridgeError(f"无法加载 Win32 API: {exc}") from exc


_PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
_GA_ROOT = 2
_MONITOR_DEFAULTTONULL = 0
_DESKTOP_SWITCHDESKTOP = 0x0100
_WM_HOTKEY = 0x0312
_PM_NOREMOVE = 0x0000
_PM_REMOVE = 0x0001
_MOD_NOREPEAT = 0x4000
_VK_F8 = 0x77
_ERROR_ALREADY_EXISTS = 183
_DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = ctypes.c_void_p(-4)

_ALLOWED_ACTIONS = frozenset({"tab", "x", "left", "right"})
_TOKEN_CHARS = frozenset(
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-"
)
_HOTKEY_STOP_EVENT = object()


def _require_windows() -> None:
    if not _IS_WINDOWS or _user32 is None or _kernel32 is None:
        raise BridgeError("Win32 bridge 只能在 Windows 上运行")


def _configure_dpi_awareness() -> None:
    """Use one process-wide physical-pixel coordinate space."""

    if not _IS_WINDOWS or _user32 is None:
        return
    try:
        fn = _user32.SetProcessDpiAwarenessContext
        fn.argtypes = [ctypes.c_void_p]
        fn.restype = ctypes.c_bool
        fn(_DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2)
        return
    except (AttributeError, OSError):
        pass
    if _shcore is not None:
        try:
            fn = _shcore.SetProcessDpiAwareness
            fn.argtypes = [ctypes.c_int]
            fn.restype = ctypes.c_long
            fn(2)  # PROCESS_PER_MONITOR_DPI_AWARE
        except (AttributeError, OSError):
            pass


def _set_api_signatures() -> None:
    """Set explicit ctypes signatures for every Win32 call we use."""

    if not _IS_WINDOWS or _user32 is None or _kernel32 is None:
        return

    u = _user32
    k = _kernel32

    u.EnumWindows.argtypes = [ctypes.c_void_p, ctypes.c_ssize_t]
    u.EnumWindows.restype = ctypes.c_bool
    u.IsWindow.argtypes = [ctypes.c_void_p]
    u.IsWindow.restype = ctypes.c_bool
    u.IsWindowVisible.argtypes = [ctypes.c_void_p]
    u.IsWindowVisible.restype = ctypes.c_bool
    u.IsIconic.argtypes = [ctypes.c_void_p]
    u.IsIconic.restype = ctypes.c_bool
    u.GetWindowTextLengthW.argtypes = [ctypes.c_void_p]
    u.GetWindowTextLengthW.restype = ctypes.c_int
    u.GetWindowTextW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_int]
    u.GetWindowTextW.restype = ctypes.c_int
    u.GetForegroundWindow.argtypes = []
    u.GetForegroundWindow.restype = ctypes.c_void_p
    u.SetForegroundWindow.argtypes = [ctypes.c_void_p]
    u.SetForegroundWindow.restype = ctypes.c_bool
    u.ShowWindow.argtypes = [ctypes.c_void_p, ctypes.c_int]
    u.ShowWindow.restype = ctypes.c_bool
    u.BringWindowToTop.argtypes = [ctypes.c_void_p]
    u.BringWindowToTop.restype = ctypes.c_bool
    u.GetWindowThreadProcessId.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint32)]
    u.GetWindowThreadProcessId.restype = ctypes.c_uint32
    u.GetClientRect.argtypes = [ctypes.c_void_p, ctypes.POINTER(_RECT)]
    u.GetClientRect.restype = ctypes.c_bool
    u.ClientToScreen.argtypes = [ctypes.c_void_p, ctypes.POINTER(_POINT)]
    u.ClientToScreen.restype = ctypes.c_bool
    u.ScreenToClient.argtypes = [ctypes.c_void_p, ctypes.POINTER(_POINT)]
    u.ScreenToClient.restype = ctypes.c_bool
    u.GetCursorPos.argtypes = [ctypes.POINTER(_POINT)]
    u.GetCursorPos.restype = ctypes.c_bool
    u.WindowFromPoint.argtypes = [_POINT]
    u.WindowFromPoint.restype = ctypes.c_void_p
    u.GetAncestor.argtypes = [ctypes.c_void_p, ctypes.c_uint]
    u.GetAncestor.restype = ctypes.c_void_p
    u.MonitorFromRect.argtypes = [ctypes.POINTER(_RECT), ctypes.c_uint]
    u.MonitorFromRect.restype = ctypes.c_void_p
    u.GetMonitorInfoW.argtypes = [ctypes.c_void_p, ctypes.POINTER(_MONITORINFO)]
    u.GetMonitorInfoW.restype = ctypes.c_bool
    u.OpenInputDesktop.argtypes = [ctypes.c_uint, ctypes.c_bool, ctypes.c_uint]
    u.OpenInputDesktop.restype = ctypes.c_void_p
    u.CloseDesktop.argtypes = [ctypes.c_void_p]
    u.CloseDesktop.restype = ctypes.c_bool
    u.RegisterHotKey.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_uint, ctypes.c_uint]
    u.RegisterHotKey.restype = ctypes.c_bool
    u.UnregisterHotKey.argtypes = [ctypes.c_void_p, ctypes.c_int]
    u.UnregisterHotKey.restype = ctypes.c_bool
    u.PeekMessageW.argtypes = [ctypes.POINTER(_MSG), ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint, ctypes.c_uint]
    u.PeekMessageW.restype = ctypes.c_bool
    u.GetMessageW.argtypes = [ctypes.POINTER(_MSG), ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint]
    u.GetMessageW.restype = ctypes.c_int
    u.PostThreadMessageW.argtypes = [
        ctypes.c_uint32,
        ctypes.c_uint,
        ctypes.c_size_t,
        ctypes.c_ssize_t,
    ]
    u.PostThreadMessageW.restype = ctypes.c_bool
    u.GetSystemMetrics.argtypes = [ctypes.c_int]
    u.GetSystemMetrics.restype = ctypes.c_int
    u.GetWindow.argtypes = [ctypes.c_void_p, ctypes.c_uint]
    u.GetWindow.restype = ctypes.c_void_p
    u.GetTopWindow.argtypes = [ctypes.c_void_p]
    u.GetTopWindow.restype = ctypes.c_void_p
    u.GetWindowRect.argtypes = [ctypes.c_void_p, ctypes.POINTER(_RECT)]
    u.GetWindowRect.restype = ctypes.c_bool

    k.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_bool, ctypes.c_uint32]
    k.OpenProcess.restype = ctypes.c_void_p
    k.QueryFullProcessImageNameW.argtypes = [
        ctypes.c_void_p,
        ctypes.c_uint32,
        ctypes.c_wchar_p,
        ctypes.POINTER(ctypes.c_uint32),
    ]
    k.QueryFullProcessImageNameW.restype = ctypes.c_bool
    k.CloseHandle.argtypes = [ctypes.c_void_p]
    k.CloseHandle.restype = ctypes.c_bool
    k.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p]
    k.CreateMutexW.restype = ctypes.c_void_p
    k.GetTickCount64.argtypes = []
    k.GetTickCount64.restype = ctypes.c_uint64
    k.GetCurrentThreadId.argtypes = []
    k.GetCurrentThreadId.restype = ctypes.c_uint32
    if _dwmapi is not None:
        _dwmapi.DwmGetWindowAttribute.argtypes = [
            ctypes.c_void_p,
            ctypes.c_uint,
            ctypes.c_void_p,
            ctypes.c_uint,
        ]
        _dwmapi.DwmGetWindowAttribute.restype = ctypes.c_long


if _IS_WINDOWS:
    _set_api_signatures()


def _last_error() -> int:
    try:
        return int(ctypes.get_last_error())
    except (AttributeError, ValueError):
        return 0


def _norm_path(value: str | os.PathLike[str]) -> str:
    return os.path.normcase(os.path.abspath(os.fspath(value)))


def _same_path(left: str | os.PathLike[str], right: str | os.PathLike[str]) -> bool:
    return _norm_path(left) == _norm_path(right)


def validate_action(action: str) -> str:
    if not isinstance(action, str):
        raise BridgeError("action 必须是 tab、x、left 或 right")
    normalized = action.strip().lower()
    if normalized not in _ALLOWED_ACTIONS:
        raise BridgeError("禁止的 action；只允许 tab、x、left、right")
    return normalized


def validate_client_point(point: tuple[int, int] | list[int], width: int, height: int) -> tuple[int, int]:
    if not isinstance(point, (tuple, list)) or len(point) != 2:
        raise BridgeError("点击坐标必须是 (x, y)")
    x, y = point
    if type(x) is not int or type(y) is not int:
        raise BridgeError("点击坐标必须是整数")
    if width <= 0 or height <= 0 or not (0 <= x < width and 0 <= y < height):
        raise BridgeError("点击坐标超出游戏客户区")
    return x, y


def deadline_is_valid(now_tick: int, deadline_tick: int) -> bool:
    return int(now_tick) <= int(deadline_tick)


def _make_token() -> str:
    return secrets.token_urlsafe(24)


def _session_text(active: bool, token: str) -> str:
    if not token or any(ch not in _TOKEN_CHARS for ch in token):
        raise BridgeError("session token 含有非法字符")
    return f"[session]\nActive={'1' if active else '0'}\nToken={token}\n"


def _parse_session(text: str) -> tuple[bool, str]:
    parser = configparser.ConfigParser(interpolation=None, strict=True)
    try:
        parser.read_string(text)
        active = parser.get("session", "Active")
        token = parser.get("session", "Token")
    except (configparser.Error, KeyError) as exc:
        raise BridgeError("session.ini 无效") from exc
    if active not in {"0", "1"} or not token or any(ch not in _TOKEN_CHARS for ch in token):
        raise BridgeError("session.ini 无效")
    return active == "1", token


def _runtime_candidates(base_dir: Path) -> Iterable[Path]:
    runtime_json = base_dir / "runtime.json"
    if runtime_json.is_file():
        try:
            value = json.loads(runtime_json.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError):
            value = None
        if isinstance(value, dict):
            for key in ("runtime", "runtime_path", "path", "executable"):
                candidate = value.get(key)
                if isinstance(candidate, str) and candidate.strip():
                    yield Path(candidate.strip().strip('"'))

    local_app_data = os.environ.get("LOCALAPPDATA")
    program_files = os.environ.get("ProgramFiles")
    program_files_x86 = os.environ.get("ProgramFiles(x86)")
    roots: list[Path] = []
    if local_app_data:
        roots.extend(
            [
                Path(local_app_data) / "Programs" / "AutoHotkey" / "v2" / "AutoHotkey64.exe",
                Path(local_app_data) / "Programs" / "AutoHotkey" / "AutoHotkey64.exe",
            ]
        )
    for env_root in (program_files, program_files_x86):
        if env_root:
            roots.extend(
                [
                    Path(env_root) / "AutoHotkey" / "v2" / "AutoHotkey64.exe",
                    Path(env_root) / "AutoHotkey" / "AutoHotkey64.exe",
                ]
            )
    yield from roots
    for root in (
        Path(local_app_data) / "Programs" / "AutoHotkey" if local_app_data else None,
        Path(program_files) / "AutoHotkey" if program_files else None,
        Path(program_files_x86) / "AutoHotkey" if program_files_x86 else None,
    ):
        if root is None or not root.is_dir():
            continue
        try:
            yield from root.rglob("AutoHotkey64.exe")
        except OSError:
            continue


def find_runtime(base_dir: Path, runtime_path: str | os.PathLike[str] | None = None) -> Path:
    candidates: list[Path] = []
    if runtime_path is not None:
        candidates.append(Path(runtime_path))
    else:
        candidates.extend(_runtime_candidates(base_dir))
    seen: set[str] = set()
    for candidate in candidates:
        try:
            resolved = candidate.expanduser().resolve(strict=True)
        except (OSError, RuntimeError):
            continue
        key = _norm_path(resolved)
        if key in seen:
            continue
        seen.add(key)
        if resolved.is_file() and resolved.name.casefold() == "autohotkey64.exe":
            return resolved
    if runtime_path is not None:
        raise BridgeError(f"找不到指定 AutoHotkey64.exe: {runtime_path}")
    raise BridgeError("找不到 AutoHotkey64.exe，请安装 AutoHotkey v2 或传入 runtime_path")


def _window_title(hwnd: int) -> str:
    length = int(_user32.GetWindowTextLengthW(hwnd))
    buffer = ctypes.create_unicode_buffer(max(length + 1, 1))
    _user32.GetWindowTextW(hwnd, buffer, len(buffer))
    return buffer.value


def _process_path(pid: int) -> str:
    handle = _kernel32.OpenProcess(_PROCESS_QUERY_LIMITED_INFORMATION, False, int(pid))
    if not handle:
        raise BridgeError(f"无法读取进程路径 pid={pid}")
    try:
        capacity = 32768
        buffer = ctypes.create_unicode_buffer(capacity)
        size = ctypes.c_uint32(capacity)
        if not _kernel32.QueryFullProcessImageNameW(handle, 0, buffer, ctypes.byref(size)):
            raise BridgeError(f"无法读取进程完整路径 pid={pid}，Win32={_last_error()}")
        return buffer.value[: int(size.value)]
    finally:
        _kernel32.CloseHandle(handle)


def _window_pid(hwnd: int) -> int:
    pid = ctypes.c_uint32(0)
    if not _user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid)):
        raise BridgeError(f"无法读取窗口 PID hwnd={hwnd}")
    return int(pid.value)


def _client_screen_rect(hwnd: int) -> tuple[int, int, int, int]:
    rect = _RECT()
    if not _user32.GetClientRect(hwnd, ctypes.byref(rect)):
        raise BridgeError(f"无法读取客户区 hwnd={hwnd}")
    width = int(rect.right - rect.left)
    height = int(rect.bottom - rect.top)
    if width <= 0 or height <= 0:
        raise BridgeError("游戏客户区尺寸无效")
    top_left = _POINT(0, 0)
    bottom_right = _POINT(width, height)
    if not _user32.ClientToScreen(hwnd, ctypes.byref(top_left)):
        raise BridgeError("无法将客户区左上角转换为屏幕坐标")
    if not _user32.ClientToScreen(hwnd, ctypes.byref(bottom_right)):
        raise BridgeError("无法将客户区右下角转换为屏幕坐标")
    return int(top_left.x), int(top_left.y), int(bottom_right.x), int(bottom_right.y)


def _foreground_root(hwnd: int) -> bool:
    foreground = _user32.GetForegroundWindow()
    if not foreground:
        return False
    if int(foreground) == int(hwnd):
        return True
    root = _user32.GetAncestor(foreground, _GA_ROOT)
    return bool(root) and int(root) == int(hwnd)


def _root_window(hwnd: int) -> int:
    root = _user32.GetAncestor(hwnd, _GA_ROOT)
    return int(root or hwnd)


def _monitor_contains(rect: tuple[int, int, int, int]) -> bool:
    monitor_rect = _RECT(*[int(v) for v in rect])
    monitor = _user32.MonitorFromRect(ctypes.byref(monitor_rect), _MONITOR_DEFAULTTONULL)
    if not monitor:
        return False
    info = _MONITORINFO()
    info.cbSize = ctypes.sizeof(_MONITORINFO)
    if not _user32.GetMonitorInfoW(monitor, ctypes.byref(info)):
        return False
    screen = info.rcMonitor
    return (
        int(screen.left) <= rect[0]
        and int(screen.top) <= rect[1]
        and int(screen.right) >= rect[2]
        and int(screen.bottom) >= rect[3]
    )


def _rects_intersect(
    first: tuple[int, int, int, int], second: tuple[int, int, int, int]
) -> bool:
    return (
        first[0] < second[2]
        and second[0] < first[2]
        and first[1] < second[3]
        and second[1] < first[3]
    )


def _window_rect(
    hwnd: int,
) -> tuple[bool, tuple[int, int, int, int] | None]:
    """Read a window rectangle and preserve the Win32 success bit.

    ``GetWindowRect`` can succeed for a zero-area helper window.  That is a
    valid observation which must be skipped by the overlay scan; it is not the
    same as an API failure, which remains fail-closed.
    """

    rect = _RECT()
    if not _user32.GetWindowRect(hwnd, ctypes.byref(rect)):
        return False, None
    value = (int(rect.left), int(rect.top), int(rect.right), int(rect.bottom))
    if value[2] <= value[0] or value[3] <= value[1]:
        return True, None
    return True, value


def _window_is_cloaked(hwnd: int) -> bool:
    if _dwmapi is None:
        return False
    cloaked = ctypes.c_uint32(0)
    result = _dwmapi.DwmGetWindowAttribute(
        hwnd,
        14,  # DWMWA_CLOAKED
        ctypes.byref(cloaked),
        ctypes.sizeof(cloaked),
    )
    if int(result) != 0:
        # Failure to prove that a visible window is cloaked is fail-closed for
        # the overlay check: treat it as an obstruction candidate.
        return False
    return bool(cloaked.value)


def _format_rect(rect: tuple[int, int, int, int] | None) -> str:
    if rect is None:
        return "unknown"
    return "(" + ", ".join(str(int(value)) for value in rect) + ")"


def _overlay_descriptor(
    hwnd: int,
    rect: tuple[int, int, int, int] | None,
    reason: str,
) -> str:
    """Return a bounded diagnostic without reading potentially sensitive titles."""

    pid_text = "unknown"
    exe_name = "<unknown>"
    try:
        pid = _window_pid(hwnd)
        pid_text = str(pid)
        try:
            exe_name = Path(_process_path(pid)).name or "<unknown>"
        except Exception:
            pass
    except Exception:
        pass

    return (
        f"{reason}: exe={exe_name!r} pid={pid_text} "
        f"hwnd={int(hwnd)} rect={_format_rect(rect)}"
    )


def _topmost_overlay_failure(
    hwnd: int, client_rect: tuple[int, int, int, int]
) -> str | None:
    """Describe the first visible, uncloaked top-level window above target."""

    current = int(_user32.GetTopWindow(None) or 0)
    while current:
        if current == int(hwnd):
            return None
        if (
            _user32.IsWindow(current)
            and _user32.IsWindowVisible(current)
            and not _user32.IsIconic(current)
            and not _window_is_cloaked(current)
        ):
            read_ok, overlay_rect = _window_rect(current)
            if not read_ok:
                return _overlay_descriptor(current, None, "GetWindowRect 读取失败")
            if overlay_rect is None:
                # A successful zero-area helper window has no drawable area.
                current = int(_user32.GetWindow(current, 2) or 0)  # GW_HWNDNEXT
                continue
            if _rects_intersect(overlay_rect, client_rect):
                return _overlay_descriptor(current, overlay_rect, "上层窗口与游戏客户区相交")
        current = int(_user32.GetWindow(current, 2) or 0)  # GW_HWNDNEXT
    # If the target was not found in the top-level z-order, do not guess.
    return _overlay_descriptor(hwnd, None, "游戏窗口不在当前顶层窗口顺序中")


def _topmost_overlay_intersects(hwnd: int, client_rect: tuple[int, int, int, int]) -> bool:
    """Return True when a visible top-level window above target overlaps it."""

    return _topmost_overlay_failure(hwnd, client_rect) is not None


def _input_desktop_is_available() -> bool:
    desktop = _user32.OpenInputDesktop(0, False, _DESKTOP_SWITCHDESKTOP)
    if not desktop:
        return False
    _user32.CloseDesktop(desktop)
    return True


def _surface_points(rect: tuple[int, int, int, int]) -> tuple[tuple[int, int], ...]:
    left, top, right, bottom = rect
    x2 = max(left, right - 1)
    y2 = max(top, bottom - 1)
    center = ((left + right - 1) // 2, (top + bottom - 1) // 2)
    values = ((left, top), (x2, top), (left, y2), (x2, y2), center)
    return tuple(dict.fromkeys(values))


def _point_belongs_to(hwnd: int, screen_point: tuple[int, int]) -> bool:
    point = _POINT(*[int(v) for v in screen_point])
    found = _user32.WindowFromPoint(point)
    if not found:
        return False
    return _root_window(int(found)) == int(hwnd)


def _surface_is_unobscured(hwnd: int, rect: tuple[int, int, int, int]) -> bool:
    """Require the game to own representative surface points, not the entire client rectangle.

    Small helper/status overlays are common in the user's setup. Rejecting any top-level
    rectangle intersection made the tool unusable even when the game itself remained
    visible and all sampled points were unobstructed. Actual click targets are still
    checked with WindowFromPoint immediately before every click.
    """

    if not _input_desktop_is_available() or not _monitor_contains(rect):
        return False
    return all(_point_belongs_to(hwnd, point) for point in _surface_points(rect))


def _surface_failure_reason(hwnd: int, rect: tuple[int, int, int, int]) -> str | None:
    """Return a user-visible reason for rejecting a client surface."""

    if not _input_desktop_is_available():
        return "输入桌面不可用"
    if not _monitor_contains(rect):
        return f"游戏客户区未完整位于单一显示器内 rect={_format_rect(rect)}"
    # Do not reject merely because some top-level window rectangle overlaps the
    # client. Small status/helper overlays are allowed when the representative game
    # points remain visible. Click coordinates are independently verified at send time.
    for point in _surface_points(rect):
        if not _point_belongs_to(hwnd, point):
            return f"游戏客户区五点命中失败 point=({point[0]}, {point[1]})"
    return None


def _capture_crop_box(
    rect: tuple[int, int, int, int],
    virtual_rect: tuple[int, int, int, int],
    capture_size: tuple[int, int],
) -> tuple[int, int, int, int]:
    """Map Win32 logical screen coordinates to ImageGrab physical pixels."""

    left, top, right, bottom = rect
    virtual_left, virtual_top, virtual_right, virtual_bottom = virtual_rect
    virtual_width = virtual_right - virtual_left
    virtual_height = virtual_bottom - virtual_top
    capture_width, capture_height = capture_size
    if virtual_width <= 0 or virtual_height <= 0 or capture_width <= 0 or capture_height <= 0:
        raise BridgeError("无法确定桌面 DPI 缩放")
    scale_x = capture_width / virtual_width
    scale_y = capture_height / virtual_height
    # 当前工具只支持同一虚拟桌面上近似一致的缩放。差异过大时宁可停机。
    if not (0.5 <= scale_x <= 4.0 and 0.5 <= scale_y <= 4.0):
        raise BridgeError("桌面 DPI 缩放比例异常")
    if abs(scale_x - scale_y) > max(scale_x, scale_y) * 0.05:
        raise BridgeError("多显示器 DPI 缩放不一致，暂不支持安全截图")
    box = (
        int(round((left - virtual_left) * scale_x)),
        int(round((top - virtual_top) * scale_y)),
        int(round((right - virtual_left) * scale_x)),
        int(round((bottom - virtual_top) * scale_y)),
    )
    if box[2] <= box[0] or box[3] <= box[1]:
        raise BridgeError("游戏客户区物理像素范围无效")
    # Do not fail merely because the window is a few pixels beyond a monitor edge.
    # capture() clips to the desktop and pads the missing client pixels so client
    # coordinates remain stable while the user moves the window.
    return box


def _enum_visible_games() -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    callback_type = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_ssize_t)

    @callback_type
    def callback(hwnd: int, _lparam: int) -> bool:
        hwnd = int(hwnd)
        if not _user32.IsWindow(hwnd) or not _user32.IsWindowVisible(hwnd) or _user32.IsIconic(hwnd):
            return True
        if _window_title(hwnd) != "佣兵传说":
            return True
        try:
            pid = _window_pid(hwnd)
            exe_path = _process_path(pid)
        except BridgeError:
            return True
        if Path(exe_path).name.casefold() != "neodark.exe":
            return True
        try:
            rect = _client_screen_rect(hwnd)
        except BridgeError:
            return True
        found.append(
            {
                "hwnd": hwnd,
                "pid": pid,
                "width": rect[2] - rect[0],
                "height": rect[3] - rect[1],
                "exe_path": exe_path,
                "title": "佣兵传说",
                "client_rect": rect,
            }
        )
        return True

    if not _user32.EnumWindows(callback, 0):
        raise BridgeError(f"EnumWindows 失败，Win32={_last_error()}")
    return found


class Bridge:
    """Single-instance, fail-closed Win32 bridge."""

    HOTKEY_ID = 0x4C50

    def __init__(self, base_dir: Path, *, runtime_path: str | os.PathLike[str] | None = None) -> None:
        _require_windows()
        _configure_dpi_awareness()
        self.base_dir = Path(base_dir).expanduser().resolve()
        if not self.base_dir.is_dir():
            raise BridgeError(f"bridge 目录不存在: {self.base_dir}")
        self.sender_script = self.base_dir / "sender.ahk"
        if not self.sender_script.is_file():
            raise BridgeError(f"缺少 sender.ahk: {self.sender_script}")
        self.runtime_path = find_runtime(self.base_dir, runtime_path)

        self._mutex: Any | None = None
        self._bound: dict[str, Any] | None = None
        self._session_token: str | None = None
        self._session_active = False
        self._hotkey_installed = False
        self._hotkey_callback: Callable[[], Any] | None = None
        self._hotkey_events: queue.Queue[object] = queue.Queue()
        self._hotkey_stop = threading.Event()
        self._hotkey_ready = threading.Event()
        self._hotkey_thread: threading.Thread | None = None
        self._hotkey_thread_id: int | None = None
        self._hotkey_start_error: str | None = None
        self._hotkey_runtime_error: str | None = None
        self._pending_process: Any | None = None
        self._send_inflight = False
        self._lock = threading.RLock()
        self._closed = False

        self._acquire_mutex()
        try:
            self._session_token = _make_token()
            self._write_session(False, self._session_token)
        except Exception:
            self._release_mutex()
            raise

    @property
    def session_path(self) -> Path:
        return self.base_dir / "session.ini"

    def _assert_open(self) -> None:
        if self._closed:
            raise BridgeError("Bridge 已关闭")

    def _acquire_mutex(self) -> None:
        name = "Local\\LapisAutoBridge-" + hashlib.sha256(
            _norm_path(self.base_dir).encode("utf-8", errors="replace")
        ).hexdigest()[:24]
        handle = _kernel32.CreateMutexW(None, True, name)
        if not handle:
            raise BridgeError(f"无法创建单实例 mutex，Win32={_last_error()}")
        if _last_error() == _ERROR_ALREADY_EXISTS:
            _kernel32.CloseHandle(handle)
            raise BridgeError("已有另一个 lapis-auto 实例正在运行")
        self._mutex = handle

    def _release_mutex(self) -> None:
        if self._mutex:
            _kernel32.CloseHandle(self._mutex)
            self._mutex = None

    def _write_session(self, active: bool, token: str) -> None:
        text = _session_text(active, token)
        fd, temporary_name = tempfile.mkstemp(
            prefix=".session-", suffix=".tmp", dir=str(self.base_dir), text=True
        )
        try:
            with os.fdopen(fd, "w", encoding="ascii", newline="\n") as handle:
                handle.write(text)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_name, self.session_path)
        except Exception:
            try:
                os.unlink(temporary_name)
            except OSError:
                pass
            raise

    def _read_session(self) -> tuple[bool, str]:
        try:
            text = self.session_path.read_text(encoding="ascii")
        except (OSError, UnicodeError) as exc:
            raise BridgeError("无法读取 session.ini") from exc
        return _parse_session(text)

    def select_game(self) -> dict[str, Any]:
        """Identify the single visible game window without requiring a focus switch.

        Selection itself is read-only and sends no input, so forcing the user to race a
        countdown just to bind the only visible NeoDark window adds friction without
        improving input safety. Foreground/surface checks still apply to capture/session
        start and every actual input.
        """

        self._assert_open()
        candidates = _enum_visible_games()
        if len(candidates) != 1:
            raise BridgeError(f"需要唯一的可见佣兵传说窗口，实际找到 {len(candidates)} 个")
        candidate = candidates[0]
        return {
            "hwnd": int(candidate["hwnd"]),
            "pid": int(candidate["pid"]),
            "width": int(candidate["width"]),
            "height": int(candidate["height"]),
            "exe_path": str(candidate["exe_path"]),
        }

    def _snapshot_bound(self, expected: dict[str, Any] | None = None) -> dict[str, Any]:
        bound = expected if expected is not None else self._bound
        if not bound:
            raise BridgeError("尚未 bind 游戏窗口")
        hwnd = int(bound["hwnd"])
        if not _user32.IsWindow(hwnd):
            raise BridgeError("游戏窗口已不存在")
        title = _window_title(hwnd)
        pid = _window_pid(hwnd)
        exe_path = _process_path(pid)
        rect = _client_screen_rect(hwnd)
        return {
            "hwnd": hwnd,
            "pid": pid,
            "width": rect[2] - rect[0],
            "height": rect[3] - rect[1],
            "exe_path": exe_path,
            "title": title,
            "client_rect": rect,
            "visible": bool(_user32.IsWindowVisible(hwnd)),
            "minimized": bool(_user32.IsIconic(hwnd)),
            "foreground": _foreground_root(hwnd),
        }

    def _validate_bound(
        self,
        *,
        check_surface: bool = False,
        require_foreground: bool = True,
        expected: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        snapshot = self._snapshot_bound(expected)
        expected = expected if expected is not None else self._bound
        assert expected is not None
        if snapshot["pid"] != int(expected["pid"]):
            raise BridgeError("游戏窗口 PID 已变化")
        if snapshot["width"] != int(expected["width"]) or snapshot["height"] != int(expected["height"]):
            raise BridgeError("游戏客户区尺寸已变化")
        if snapshot["title"] != "佣兵传说":
            raise BridgeError("游戏窗口标题已变化")
        if Path(snapshot["exe_path"]).name.casefold() != "neodark.exe" or not _same_path(
            snapshot["exe_path"], expected["exe_path"]
        ):
            raise BridgeError("游戏进程路径已变化")
        if not snapshot["visible"] or snapshot["minimized"]:
            raise BridgeError("游戏窗口不可见或已最小化")
        if require_foreground and not snapshot["foreground"]:
            raise BridgeError("游戏窗口已失去前台焦点")
        if check_surface:
            surface_failure = _surface_failure_reason(snapshot["hwnd"], snapshot["client_rect"])
            if surface_failure is not None:
                raise BridgeError(surface_failure)
        return snapshot

    def bind(self, info: dict[str, Any]) -> None:
        self._assert_open()
        if not isinstance(info, dict):
            raise BridgeError("bind info 必须是字典")
        required = ("hwnd", "pid", "width", "height", "exe_path")
        if any(key not in info for key in required):
            raise BridgeError("bind info 缺少 hwnd/pid/width/height/exe_path")
        try:
            candidate = {
                "hwnd": int(info["hwnd"]),
                "pid": int(info["pid"]),
                "width": int(info["width"]),
                "height": int(info["height"]),
                "exe_path": str(info["exe_path"]),
            }
        except (TypeError, ValueError, OverflowError) as exc:
            raise BridgeError("bind info 数值无效") from exc
        if candidate["hwnd"] <= 0 or candidate["pid"] <= 0:
            raise BridgeError("bind info 的 hwnd/pid 无效")
        if candidate["width"] <= 0 or candidate["height"] <= 0:
            raise BridgeError("bind info 的客户区尺寸无效")
        old = self._bound
        self._bound = candidate
        try:
            self._validate_bound(check_surface=False, require_foreground=False)
        except Exception:
            self._bound = old
            raise

    def activate_bound(self) -> None:
        """Bring the already-bound game to the foreground without sending game input."""

        self._assert_open()
        snapshot = self._validate_bound(check_surface=False, require_foreground=False)
        hwnd = int(snapshot["hwnd"])
        try:
            _user32.BringWindowToTop(hwnd)
            _user32.SetForegroundWindow(hwnd)
        except (AttributeError, OSError) as exc:
            raise BridgeError(f"无法激活游戏窗口: {exc}") from exc
        # SetForegroundWindow can be asynchronous; verify briefly rather than racing it.
        for _ in range(8):
            if _foreground_root(hwnd):
                return
            import time as _time
            _time.sleep(0.025)
        raise BridgeError("无法把游戏窗口切到前台")

    def capture(self) -> Image.Image:
        self._assert_open()
        # 截图本身不需要前台焦点。运行时 UI、日志窗口或启动按钮可能短暂夺取焦点；
        # 识别阶段应继续观察当前游戏画面。真正发送键鼠前仍由 send() 强制要求前台。
        # Read-only capture must not require the whole client rectangle to be owned
        # by NeoDark. This game uses a small Typeless status overlay inside the client
        # (for example the top-left auto-attack banner), which made five-point surface
        # sampling reject every frame even though the battle HUD remained visible.
        snapshot = self._validate_bound(check_surface=False, require_foreground=False)
        left, top, right, bottom = snapshot["client_rect"]
        try:
            virtual_left = int(_user32.GetSystemMetrics(76)) if hasattr(_user32, "GetSystemMetrics") else 0
            virtual_top = int(_user32.GetSystemMetrics(77)) if hasattr(_user32, "GetSystemMetrics") else 0
        except (AttributeError, OSError):
            virtual_left = virtual_top = 0
        try:
            screen = ImageGrab.grab(all_screens=True)
            # 用截图完成时刻作为新鲜度基准，避免把 ImageGrab 自身耗时
            # 误算成“画面过期”。
            captured_tick = self._tick_count()
        except Exception as exc:
            raise BridgeError(f"无法截图: {exc}") from exc
        try:
            virtual_width = int(_user32.GetSystemMetrics(78))
            virtual_height = int(_user32.GetSystemMetrics(79))
            virtual_rect = (
                virtual_left,
                virtual_top,
                virtual_left + virtual_width,
                virtual_top + virtual_height,
            )
            crop_box = _capture_crop_box(
                (left, top, right, bottom),
                virtual_rect,
                screen.size,
            )
            physical_width = crop_box[2] - crop_box[0]
            physical_height = crop_box[3] - crop_box[1]
            clipped = (
                max(0, crop_box[0]),
                max(0, crop_box[1]),
                min(screen.size[0], crop_box[2]),
                min(screen.size[1], crop_box[3]),
            )
            visible_width = max(0, clipped[2] - clipped[0])
            visible_height = max(0, clipped[3] - clipped[1])
            visible_ratio = (
                (visible_width * visible_height) / (physical_width * physical_height)
                if physical_width > 0 and physical_height > 0
                else 0.0
            )
            if visible_ratio < 0.75:
                raise BridgeError("游戏窗口有超过 25% 移出桌面，无法可靠识别")
            image = Image.new("RGB", (physical_width, physical_height), (0, 0, 0))
            if visible_width > 0 and visible_height > 0:
                visible = screen.crop(clipped).convert("RGB")
                image.paste(
                    visible,
                    (clipped[0] - crop_box[0], clipped[1] - crop_box[1]),
                )
        except Exception as exc:
            if isinstance(exc, BridgeError):
                raise
            raise BridgeError(f"无法裁剪游戏客户区: {exc}") from exc
        expected_size = (snapshot["width"], snapshot["height"])
        # Win32/Tk 可能运行在逻辑坐标，而 ImageGrab 返回物理像素。
        # 先按 DPI 映射取得完整客户区，再缩回绑定时的逻辑尺寸供识别器统一处理。
        if image.size != expected_size:
            image = image.resize(expected_size, Image.Resampling.LANCZOS)
        image.info["captured_tick"] = captured_tick
        return image

    def get_client_cursor(self) -> tuple[int, int]:
        """Read a calibration point without requiring the game to own foreground focus.

        Clicking the tool's calibration button necessarily gives focus to the tool
        window. Requiring NeoDark to already be foreground made calibration fail even
        while the mouse was visibly over the game. This method is read-only, so it only
        requires that the cursor's actual screen pixel belongs to the bound game.
        """

        self._assert_open()
        snapshot = self._validate_bound(check_surface=False, require_foreground=False)
        point = _POINT()
        if not _user32.GetCursorPos(ctypes.byref(point)):
            raise BridgeError("无法读取鼠标位置")
        screen_point = (int(point.x), int(point.y))
        if not _point_belongs_to(snapshot["hwnd"], screen_point):
            raise BridgeError("校准时鼠标必须停在游戏可见区域内，不能停在工具窗口或其他浮窗上")
        if not _user32.ScreenToClient(snapshot["hwnd"], ctypes.byref(point)):
            raise BridgeError("无法转换鼠标客户区坐标")
        return int(point.x), int(point.y)

    def activate_game(self) -> None:
        """Bring the already-bound game to foreground after an explicit Start click."""

        self._assert_open()
        snapshot = self._validate_bound(check_surface=False, require_foreground=False)
        hwnd = snapshot["hwnd"]
        if snapshot["minimized"]:
            _user32.ShowWindow(hwnd, 9)  # SW_RESTORE
        _user32.BringWindowToTop(hwnd)
        _user32.SetForegroundWindow(hwnd)
        for _ in range(8):
            if _foreground_root(hwnd):
                self._validate_bound(check_surface=False, require_foreground=True)
                return
            time.sleep(0.05)
        raise BridgeError("无法自动切回游戏窗口；请手动点一下游戏后再开始")

    def _tick_count(self) -> int:
        return int(_kernel32.GetTickCount64())

    def begin_session(self) -> str:
        self._assert_open()
        with self._lock:
            if self._send_inflight:
                raise BridgeError("已有 sender 正在运行，无法开始新 session")
            if self._pending_process is not None and self._pending_process.poll() is None:
                raise BridgeError("上一次 sender 仍在运行，无法开始新 session")
            self._validate_bound(check_surface=False)
            token = _make_token()
            self._write_session(True, token)
            self._session_token = token
            self._session_active = True
            return token

    def cancel(self) -> None:
        if self._closed:
            return
        with self._lock:
            token = _make_token()
            self._session_active = False
            self._session_token = token
            self._write_session(False, token)

    def _reap_pending(self) -> None:
        process = self._pending_process
        if process is None:
            return
        if process.poll() is None:
            raise BridgeError("前一次 sender 超时且仍未退出，已禁止继续输入")
        try:
            process.communicate(timeout=0)
        except subprocess.TimeoutExpired:
            raise BridgeError("前一次 sender 状态仍不确定，已禁止继续输入")
        finally:
            self._pending_process = None
            self._send_inflight = False

    def _invalidate_if_current(self, token: str) -> None:
        with self._lock:
            if not self._session_active or self._session_token != token:
                return
            replacement = _make_token()
            self._session_active = False
            self._session_token = replacement
            self._write_session(False, replacement)

    def _run_sender(self, command: list[str], token: str) -> None:
        try:
            process = subprocess.Popen(
                command,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
                shell=False,
            )
        except OSError as exc:
            raise BridgeError(f"无法启动 sender.ahk: {exc}") from exc
        try:
            stdout, stderr = process.communicate(timeout=1.2)
        except subprocess.TimeoutExpired as exc:
            self._pending_process = process
            try:
                self._invalidate_if_current(token)
            except Exception as cancel_exc:
                raise BridgeError(
                    "sender 超时；未强制终止，且 session 失效写入失败："
                    f"{cancel_exc}"
                ) from cancel_exc
            raise BridgeError("sender 超时；为避免遗留按键未强制终止，已取消 session") from exc
        if process.returncode != 0:
            detail = (stderr or stdout or "").strip()
            suffix = f": {detail}" if detail else ""
            raise BridgeError(f"sender 拒绝输入（exit={process.returncode}）{suffix}")

    def send(
        self,
        action: str,
        point: tuple[int, int] | None = None,
        *,
        observation_deadline_tick: int | None = None,
    ) -> None:
        self._assert_open()
        normalized = validate_action(action)
        if type(observation_deadline_tick) is not int or observation_deadline_tick < 0:
            raise BridgeError("send 必须提供有效的 observation_deadline_tick")
        self._reap_pending()
        if self._tick_count() > observation_deadline_tick:
            raise BridgeError("观察画面已过期，拒绝发送输入")
        with self._lock:
            if self._send_inflight:
                raise BridgeError("已有 sender 正在运行")
            if not self._session_active or not self._session_token:
                raise BridgeError("当前没有 active session")
            active, token = self._read_session()
            if not active or token != self._session_token:
                self._session_active = False
                raise BridgeError("session 已取消或 token 已变化")
            bound_snapshot = dict(self._bound or {})
            self._send_inflight = True

        try:
            # Do not require five arbitrary client points to be unobscured.
            # Keyboard input only requires the game foreground; mouse input below
            # validates the exact click point immediately before dispatch.
            snapshot = self._validate_bound(check_surface=False, expected=bound_snapshot)
            if normalized in {"tab", "x"}:
                if point is not None:
                    raise BridgeError(f"{normalized} action 不接受坐标")
                x_arg, y_arg = "", ""
            else:
                if point is None:
                    raise BridgeError("left/right action 必须提供客户区坐标")
                x, y = validate_client_point(point, snapshot["width"], snapshot["height"])
                screen_point = _POINT(x, y)
                if not _user32.ClientToScreen(snapshot["hwnd"], ctypes.byref(screen_point)):
                    raise BridgeError("无法将点击坐标转换为屏幕坐标")
                if not _monitor_contains(
                    (
                        int(screen_point.x),
                        int(screen_point.y),
                        int(screen_point.x) + 1,
                        int(screen_point.y) + 1,
                    )
                ):
                    raise BridgeError("点击坐标不在真实显示器范围内")
                if not _point_belongs_to(snapshot["hwnd"], (int(screen_point.x), int(screen_point.y))):
                    raise BridgeError("点击坐标下方不是游戏窗口")
                x_arg, y_arg = str(x), str(y)

            command = [
                str(self.runtime_path),
                str(self.sender_script),
                normalized,
                str(snapshot["hwnd"]),
                str(snapshot["pid"]),
                str(snapshot["width"]),
                str(snapshot["height"]),
                token,
                str(observation_deadline_tick),
                x_arg,
                y_arg,
                str(snapshot["exe_path"]),
            ]
            self._run_sender(command, token)
        finally:
            # A timed-out process remains tracked until _reap_pending observes
            # its exit; every other path releases the guard immediately.
            if self._pending_process is None:
                with self._lock:
                    self._send_inflight = False

    def _hotkey_loop(self) -> None:
        """Own the Win32 message queue used by RegisterHotKey.

        Tk may consume WM_HOTKEY messages on its main thread before a Tk
        ``after`` callback can call poll_hotkey().  Registering on this
        dedicated thread keeps the stop message out of Tk's queue.  The
        thread performs the safety-critical cancel immediately and leaves
        only a small event for the main thread callback.
        """

        thread_id = int(_kernel32.GetCurrentThreadId())
        self._hotkey_thread_id = thread_id
        message = _MSG()
        registered = False
        try:
            # Force creation of this thread's message queue before posting or
            # registering a thread hotkey.
            _user32.PeekMessageW(ctypes.byref(message), None, 0, 0, _PM_NOREMOVE)
            if not _user32.RegisterHotKey(None, self.HOTKEY_ID, _MOD_NOREPEAT, _VK_F8):
                self._hotkey_start_error = f"Win32={_last_error()}"
                return
            registered = True
            self._hotkey_ready.set()
            while not self._hotkey_stop.is_set():
                result = int(_user32.GetMessageW(ctypes.byref(message), None, 0, 0))
                if result == -1:
                    self._hotkey_runtime_error = f"GetMessageW 失败，Win32={_last_error()}"
                    break
                if result == 0:
                    break
                if int(message.message) != _WM_HOTKEY or int(message.wParam) != self.HOTKEY_ID:
                    continue
                try:
                    self.cancel()
                except Exception as exc:  # keep the main-thread callback observable
                    self._hotkey_runtime_error = f"F8 取消失败: {exc}"
                self._hotkey_events.put(_HOTKEY_STOP_EVENT)
        finally:
            if registered:
                _user32.UnregisterHotKey(None, self.HOTKEY_ID)
            self._hotkey_thread_id = None
            self._hotkey_ready.set()

    def _stop_hotkey_thread(self) -> None:
        thread = self._hotkey_thread
        if thread is None:
            return
        self._hotkey_stop.set()
        thread_id = self._hotkey_thread_id
        if thread_id is not None:
            _user32.PostThreadMessageW(thread_id, 0x0012, 0, 0)  # WM_QUIT
        if thread is not threading.current_thread():
            thread.join(timeout=1.0)
        if thread.is_alive():
            raise BridgeError("F8 热键线程未在 1 秒内退出")
        self._hotkey_thread = None
        self._hotkey_thread_id = None
        self._hotkey_installed = False

    def install_hotkey(self, callback: Callable[[], Any]) -> None:
        self._assert_open()
        if not callable(callback):
            raise BridgeError("hotkey callback 必须可调用")
        if self._hotkey_installed or self._hotkey_thread is not None:
            raise BridgeError("F8 hotkey 已安装")
        self._hotkey_callback = callback
        self._hotkey_start_error = None
        self._hotkey_runtime_error = None
        self._hotkey_stop.clear()
        self._hotkey_ready.clear()
        thread = threading.Thread(target=self._hotkey_loop, name="lapis-f8-hotkey", daemon=True)
        self._hotkey_thread = thread
        try:
            thread.start()
        except Exception:
            self._hotkey_thread = None
            self._hotkey_callback = None
            raise
        if not self._hotkey_ready.wait(timeout=1.0):
            self._stop_hotkey_thread()
            self._hotkey_callback = None
            raise BridgeError("F8 热键线程启动超时")
        if self._hotkey_start_error is not None:
            error = self._hotkey_start_error
            self._stop_hotkey_thread()
            self._hotkey_callback = None
            raise BridgeError(f"无法注册 F8 停止热键，{error}")
        self._hotkey_installed = True

    def poll_hotkey(self) -> None:
        self._assert_open()
        if not self._hotkey_installed:
            return
        while True:
            try:
                event = self._hotkey_events.get_nowait()
            except queue.Empty:
                break
            if event is not _HOTKEY_STOP_EVENT:
                continue
            callback = self._hotkey_callback
            if callback is not None:
                callback()

    def close(self) -> None:
        if self._closed:
            return
        error: Exception | None = None
        try:
            try:
                self.cancel()
            except Exception as exc:
                error = exc
            try:
                self._stop_hotkey_thread()
            except Exception as exc:
                if error is None:
                    error = exc
            self._hotkey_callback = None
        finally:
            self._release_mutex()
            self._closed = True
        if error is not None:
            raise error

    def __enter__(self) -> "Bridge":
        self._assert_open()
        return self

    def __exit__(self, _exc_type: Any, _exc: Any, _tb: Any) -> None:
        self.close()


__all__ = [
    "Bridge",
    "BridgeError",
    "deadline_is_valid",
    "find_runtime",
    "validate_action",
    "validate_client_point",
]
