"""
Pure deterministic state machine for the Lapis auto-level helper.

This module deliberately does not import Tk/OpenCV/Bridge.  It only converts
observed scene states into a small, explicit sequence of allowed actions.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
import math
from typing import Optional


class Scene(str, Enum):
    FIELD = "field"
    BATTLE = "battle"
    VICTORY = "victory"
    INVENTORY = "inventory"
    UNKNOWN = "unknown"


class ControllerState(str, Enum):
    STOPPED = "stopped"
    FIELD_SUPPLY_RED = "field_supply_red"
    FIELD_SUPPLY_BLUE = "field_supply_blue"
    WAIT_BATTLE = "wait_battle"

    BATTLE_TAB = "battle_tab"
    BATTLE_SELECT = "battle_select"
    BATTLE_AIM = "battle_aim"
    BATTLE_CAST = "battle_cast"
    WAIT_RETRY = "wait_retry"
    RETRY_SELECT = "retry_select"
    RETRY_AIM = "retry_aim"
    RETRY_CAST = "retry_cast"

    WAIT_VICTORY = "wait_victory"
    WAIT_FIELD = "wait_field"
    PAUSED = "paused"


@dataclass(frozen=True)
class Positions:
    foot: tuple[int, int]
    red: tuple[int, int]
    blue: tuple[int, int]
    width: int = 1572
    height: int = 1181

    def validate(self) -> None:
        if self.width < 320 or self.height < 240:
            raise ValueError("游戏窗口尺寸过小")
        for name, point in (("foot", self.foot), ("red", self.red), ("blue", self.blue)):
            if (
                not isinstance(point, tuple)
                or len(point) != 2
                or any(type(v) is not int for v in point)
                or not (0 <= point[0] < self.width and 0 <= point[1] < self.height)
            ):
                raise ValueError(f"未校准或越界坐标: {name}")


@dataclass(frozen=True)
class LoopConfig:
    # Continuous mode keeps a 24-hour fail-safe rather than the old short session cap.
    max_minutes: int = 24 * 60
    max_battles: Optional[int] = None

    # User-confirmed deterministic timings.
    supply_gap: float = 2.0
    tab_to_x_gap: float = 0.25
    x_to_aim_gap: float = 1.0
    aim_to_cast_gap: float = 1.0
    retry_gap: float = 8.0
    victory_timeout: float = 20.0
    # Live evidence: normal VICTORY -> FIELD transition is ~10.1-10.6s and has
    # already reached 12.05s once. Keep a 30s grace window for server/client lag.
    return_field_timeout: float = 30.0
    unknown_timeout: float = 8.0

    # Compatibility fields kept for older callers; no longer gate the flow.
    first_round_gap: float = 8.0
    range_timeout: float = 3.0
    range_fallback_delay: float = 0.65
    effect_timeout: float = 4.0

    low_hp_ratio: float = 0.30
    first_battle_hp_ratio: float = 0.50
    first_battle_mp_ratio: float = 0.30

    def validate(self) -> None:
        if not isinstance(self.max_minutes, int) or not 1 <= self.max_minutes <= 24 * 60:
            raise ValueError("max_minutes 必须在 1-1440 分钟")
        if self.max_battles is not None and (
            not isinstance(self.max_battles, int) or not 1 <= self.max_battles <= 10000
        ):
            raise ValueError("max_battles 必须为正整数")
        for name in (
            "supply_gap",
            "tab_to_x_gap",
            "x_to_aim_gap",
            "aim_to_cast_gap",
            "retry_gap",
            "victory_timeout",
            "return_field_timeout",
            "unknown_timeout",
            "first_round_gap",
            "range_timeout",
            "range_fallback_delay",
            "effect_timeout",
        ):
            value = getattr(self, name)
            if not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
                raise ValueError(f"{name} 必须为非负有限数")
        for name in ("low_hp_ratio", "first_battle_hp_ratio", "first_battle_mp_ratio"):
            value = getattr(self, name)
            if not isinstance(value, (int, float)) or not 0 <= value <= 1:
                raise ValueError(f"{name} 必须在 0-1")


@dataclass(frozen=True)
class Observation:
    scene: Scene | str
    frame_id: int = 0
    range_ready: bool = False
    poison_effect: bool = False
    hp_ratio: Optional[float] = None
    mp_ratio: Optional[float] = None
    observation_deadline: Optional[float] = None
    observation_deadline_tick: Optional[int] = None

    def normalized_scene(self) -> Scene:
        try:
            return self.scene if isinstance(self.scene, Scene) else Scene(str(self.scene))
        except ValueError:
            return Scene.UNKNOWN


@dataclass(frozen=True)
class Action:
    kind: str
    point: Optional[tuple[int, int]] = None
    reason: str = ""
    sequence: int = 0
    observation_deadline: Optional[float] = None
    observation_deadline_tick: Optional[int] = None

    def __post_init__(self) -> None:
        if self.kind not in {"tab", "x", "left", "right"}:
            raise ValueError(f"非法动作: {self.kind}")
        if self.point is not None and (
            len(self.point) != 2 or any(type(v) is not int for v in self.point)
        ):
            raise ValueError("动作坐标必须是两个整数")


_BATTLE_ACTION_STATES = {
    ControllerState.BATTLE_TAB,
    ControllerState.BATTLE_SELECT,
    ControllerState.BATTLE_AIM,
    ControllerState.BATTLE_CAST,
    ControllerState.WAIT_RETRY,
    ControllerState.RETRY_SELECT,
    ControllerState.RETRY_AIM,
    ControllerState.RETRY_CAST,
    ControllerState.WAIT_VICTORY,
}


@dataclass
class Controller:
    positions: Positions
    config: LoopConfig = field(default_factory=LoopConfig)

    state: ControllerState = field(init=False, default=ControllerState.STOPPED)
    running: bool = field(init=False, default=False)
    paused: bool = field(init=False, default=False)
    session_token: Optional[str] = field(init=False, default=None)
    started_at: Optional[float] = field(init=False, default=None)
    state_since: Optional[float] = field(init=False, default=None)
    stop_reason: str = field(init=False, default="")
    battle_count: int = field(init=False, default=0)
    round_number: int = field(init=False, default=0)

    pending: Optional[Action] = field(init=False, default=None)
    pending_since: Optional[float] = field(init=False, default=None)
    deadline: Optional[float] = field(init=False, default=None)
    next_ready_at: Optional[float] = field(init=False, default=None)
    unknown_since: Optional[float] = field(init=False, default=None)
    last_frame_id: Optional[int] = field(init=False, default=None)
    last_action_frame_id: Optional[int] = field(init=False, default=None)
    pre_click_mp: Optional[float] = field(init=False, default=None)
    current_action_reason: str = field(init=False, default="")
    _action_sequence: int = field(init=False, default=0)
    _resume_state: Optional[ControllerState] = field(init=False, default=None)
    _stop_after_supply: bool = field(init=False, default=False)
    _observation_deadline: Optional[float] = field(init=False, default=None)
    _observation_deadline_tick: Optional[int] = field(init=False, default=None)

    def __post_init__(self) -> None:
        self.positions.validate()
        self.config.validate()

    @property
    def status_text(self) -> str:
        if self.stop_reason:
            return f"已停止：{self.stop_reason}"
        if self.paused:
            return "已暂停"
        return self.state.value

    def start(self, now: float, initial: Observation | None = None) -> None:
        self.config.validate()
        self.positions.validate()
        if not math.isfinite(now):
            raise ValueError("now 必须为有限数")
        self._reset_runtime()
        self.running = True
        self.started_at = now
        self.state_since = now
        self.session_token = f"session-{id(self):x}-{now:.9f}"
        if initial is not None and initial.normalized_scene() == Scene.FIELD:
            self.state = ControllerState.FIELD_SUPPLY_RED
        else:
            self.state = ControllerState.WAIT_BATTLE

    def pause(self, now: float) -> None:
        if self.running:
            self.cancel("已暂停；请重新开始新的 session")

    def resume(self, now: float) -> None:
        return

    def cancel(self, reason: str = "用户停止") -> None:
        self.running = False
        self.paused = False
        self.state = ControllerState.STOPPED
        self.stop_reason = reason
        self.session_token = None
        self.pending = None
        self.deadline = None
        self.next_ready_at = None
        self.unknown_since = None
        self.round_number = 0
        self._resume_state = None

    def ack(self, action: Action, success: bool, now: float) -> None:
        if self.pending != action or not self.running or self.paused:
            return
        if action.observation_deadline is not None and now >= action.observation_deadline:
            self.cancel("输入确认已过期，拒绝推进状态")
            return
        self.pending = None
        self.pending_since = None
        self.last_action_frame_id = None
        if not success:
            self.cancel("输入发送失败或窗口状态改变")
            return
        self._ack_success(action, now)

    def tick(self, obs: Observation, now: float) -> Optional[Action]:
        if not self.running or self.paused:
            return None
        if not math.isfinite(now):
            self.cancel("时钟异常")
            return None
        if self.started_at is not None and now - self.started_at >= self.config.max_minutes * 60:
            self.cancel("达到最长运行时间")
            return None
        if obs.observation_deadline is not None and now >= obs.observation_deadline:
            self.cancel("截图观察已过期，拒绝动作")
            return None

        scene = obs.normalized_scene()
        if scene == Scene.UNKNOWN:
            if self.unknown_since is None:
                self.unknown_since = now
            elif now - self.unknown_since >= self.config.unknown_timeout:
                self.cancel(f"画面未知超过 {self.config.unknown_timeout:g} 秒")
            return None

        self.unknown_since = None
        self._observation_deadline = obs.observation_deadline
        self._observation_deadline_tick = obs.observation_deadline_tick

        if self.pending is not None:
            return None
        if self.last_frame_id is not None and obs.frame_id == self.last_frame_id:
            return None
        self.last_frame_id = obs.frame_id

        if scene == Scene.INVENTORY:
            self.cancel("检测到背包画面")
            return None

        # Victory interrupts any remaining poison/retry action immediately.
        if scene == Scene.VICTORY and self.state in _BATTLE_ACTION_STATES:
            self.state = ControllerState.WAIT_FIELD
            self.state_since = now
            self.deadline = now + self.config.return_field_timeout
            return None

        # Once at least one poison cast has been attempted, a direct return to field
        # is also a valid battle completion signal on this player server.
        if (
            scene == Scene.FIELD
            and self.state in {
                ControllerState.WAIT_RETRY,
                ControllerState.RETRY_SELECT,
                ControllerState.RETRY_AIM,
                ControllerState.RETRY_CAST,
                ControllerState.WAIT_VICTORY,
                ControllerState.WAIT_FIELD,
            }
        ):
            return self._complete_battle_on_field(now)

        if scene == Scene.BATTLE and not self._check_battle_health(obs):
            return None

        if self.state == ControllerState.FIELD_SUPPLY_RED:
            if scene != Scene.FIELD:
                return None
            return self._offer(Action("right", self.positions.red, "脱战后右键红药补满"), now)

        if self.state == ControllerState.FIELD_SUPPLY_BLUE:
            if scene != Scene.FIELD:
                return None
            if self.state_since is not None and now - self.state_since < self.config.supply_gap:
                return None
            return self._offer(Action("right", self.positions.blue, "红药后等待 2 秒，右键蓝药补满"), now)

        if self.state == ControllerState.WAIT_BATTLE:
            if scene != Scene.BATTLE:
                return None
            self.round_number = 1
            self.state = ControllerState.BATTLE_TAB
            self.state_since = now
            return self._offer(Action("tab", None, "进入战斗：Tab 回到主角脚下并居中"), now)

        if self.state == ControllerState.BATTLE_TAB:
            return None

        if self.state == ControllerState.BATTLE_SELECT:
            if scene != Scene.BATTLE:
                return None
            if self.state_since is not None and now - self.state_since < self.config.tab_to_x_gap:
                return None
            return self._offer(Action("x", None, "第一轮：按 X 选择巫妖毒"), now)

        if self.state == ControllerState.BATTLE_AIM:
            if scene != Scene.BATTLE:
                return None
            if self.state_since is not None and now - self.state_since < self.config.x_to_aim_gap:
                return None
            return self._offer(Action("left", self.positions.foot, "第一轮：第一次点击脚下，展开毒范围"), now)

        if self.state == ControllerState.BATTLE_CAST:
            if scene != Scene.BATTLE:
                return None
            if self.state_since is not None and now - self.state_since < self.config.aim_to_cast_gap:
                return None
            return self._offer(Action("left", self.positions.foot, "第一轮：第二次点击脚下，确认释放巫妖毒"), now)

        if self.state == ControllerState.WAIT_RETRY:
            if scene != Scene.BATTLE:
                return None
            if self.next_ready_at is None or now < self.next_ready_at:
                return None
            self.round_number = 2
            self.state = ControllerState.RETRY_SELECT
            self.state_since = now
            return self._offer(Action("x", None, "8 秒仍在战斗：第二轮按 X 冗余施毒"), now)

        if self.state == ControllerState.RETRY_SELECT:
            return None

        if self.state == ControllerState.RETRY_AIM:
            if scene != Scene.BATTLE:
                return None
            if self.state_since is not None and now - self.state_since < self.config.x_to_aim_gap:
                return None
            return self._offer(Action("left", self.positions.foot, "第二轮：第一次点击脚下，展开毒范围"), now)

        if self.state == ControllerState.RETRY_CAST:
            if scene != Scene.BATTLE:
                return None
            if self.state_since is not None and now - self.state_since < self.config.aim_to_cast_gap:
                return None
            return self._offer(Action("left", self.positions.foot, "第二轮：第二次点击脚下，确认释放巫妖毒"), now)

        if self.state == ControllerState.WAIT_VICTORY:
            if scene == Scene.VICTORY:
                self.state = ControllerState.WAIT_FIELD
                self.state_since = now
                self.deadline = now + self.config.return_field_timeout
                return None
            if scene == Scene.BATTLE and self.deadline is not None and now >= self.deadline:
                self.cancel("第二轮施毒后仍未结束战斗")
            return None

        if self.state == ControllerState.WAIT_FIELD:
            if scene == Scene.FIELD:
                return self._complete_battle_on_field(now)
            if self.deadline is not None and now >= self.deadline:
                self.cancel("胜利后未在预期时间回到野外")
            return None

        return None

    def _complete_battle_on_field(self, now: float) -> Action:
        self.battle_count += 1
        if self.config.max_battles is not None and self.battle_count >= self.config.max_battles:
            self._stop_after_supply = True
        self.state = ControllerState.FIELD_SUPPLY_RED
        self.state_since = now
        self.deadline = None
        self.next_ready_at = None
        self.pre_click_mp = None
        return self._offer(Action("right", self.positions.red, "胜利回野外：立即右键红药补满"), now)

    def _check_battle_health(self, obs: Observation) -> bool:
        """Treat visual HP/MP as display-only telemetry.

        The current player server's compact HUD uses gradients, numbers and partial
        overlays that make bar-fill estimates materially inaccurate. A real 335/355
        HP frame was previously estimated as ~40%, which incorrectly stopped the
        continuous loop even though the three-battle trial worked. The user-confirmed
        loop already performs red/blue supply immediately after every return to FIELD,
        so HP/MP estimates must not gate the deterministic combat sequence.

        We still fail closed on structurally invalid values outside 0..1 because that
        indicates a programming error rather than an in-game condition.
        """
        if obs.hp_ratio is not None and not 0 <= obs.hp_ratio <= 1:
            self.cancel("HP 读数越界")
            return False
        if obs.mp_ratio is not None and not 0 <= obs.mp_ratio <= 1:
            self.cancel("MP 读数越界")
            return False
        return True

    def _offer(self, action: Action, now: float) -> Action:
        self._action_sequence += 1
        offered = Action(
            action.kind,
            action.point,
            action.reason,
            self._action_sequence,
            self._observation_deadline,
            self._observation_deadline_tick,
        )
        self.pending = offered
        self.pending_since = now
        self.current_action_reason = offered.reason
        return offered

    def _ack_success(self, action: Action, now: float) -> None:
        if action.kind == "right" and action.point == self.positions.red:
            if self.state == ControllerState.FIELD_SUPPLY_RED:
                self.state = ControllerState.FIELD_SUPPLY_BLUE
                self.state_since = now
            return

        if action.kind == "right" and action.point == self.positions.blue:
            if self.state == ControllerState.FIELD_SUPPLY_BLUE:
                if self._stop_after_supply:
                    self.cancel(f"已完成 {self.battle_count} 场试跑并完成战后补给")
                else:
                    self.state = ControllerState.WAIT_BATTLE
                    self.state_since = now
            return

        if action.kind == "tab" and self.state == ControllerState.BATTLE_TAB:
            self.state = ControllerState.BATTLE_SELECT
            self.state_since = now
            return

        if action.kind == "x" and self.state == ControllerState.BATTLE_SELECT:
            self.state = ControllerState.BATTLE_AIM
            self.state_since = now
            return

        if action.kind == "left" and self.state == ControllerState.BATTLE_AIM:
            self.state = ControllerState.BATTLE_CAST
            self.state_since = now
            return

        if action.kind == "left" and self.state == ControllerState.BATTLE_CAST:
            self.state = ControllerState.WAIT_RETRY
            self.state_since = now
            self.next_ready_at = now + self.config.retry_gap
            return

        if action.kind == "x" and self.state == ControllerState.RETRY_SELECT:
            self.state = ControllerState.RETRY_AIM
            self.state_since = now
            return

        if action.kind == "left" and self.state == ControllerState.RETRY_AIM:
            self.state = ControllerState.RETRY_CAST
            self.state_since = now
            return

        if action.kind == "left" and self.state == ControllerState.RETRY_CAST:
            self.state = ControllerState.WAIT_VICTORY
            self.state_since = now
            self.deadline = now + self.config.victory_timeout
            return

    def note_click_mp(self, mp_ratio: Optional[float]) -> None:
        # Kept for app compatibility; deterministic flow no longer waits for MP drop.
        if mp_ratio is not None and 0 <= mp_ratio <= 1:
            self.pre_click_mp = mp_ratio

    def _reset_runtime(self) -> None:
        self.state = ControllerState.STOPPED
        self.running = False
        self.paused = False
        self.session_token = None
        self.started_at = None
        self.state_since = None
        self.stop_reason = ""
        self.battle_count = 0
        self.round_number = 0
        self.pending = None
        self.pending_since = None
        self.deadline = None
        self.next_ready_at = None
        self.unknown_since = None
        self.last_frame_id = None
        self.last_action_frame_id = None
        self.pre_click_mp = None
        self.current_action_reason = ""
        # Keep action sequence monotonic across restarts so an old async ACK can
        # never equal an action from the new session.
        self._resume_state = None
        self._stop_after_supply = False
        self._observation_deadline = None
        self._observation_deadline_tick = None


__all__ = [
    "Action",
    "Controller",
    "ControllerState",
    "LoopConfig",
    "Observation",
    "Positions",
    "Scene",
]
