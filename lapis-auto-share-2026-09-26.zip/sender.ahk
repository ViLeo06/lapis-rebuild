#Requires AutoHotkey v2.0
#SingleInstance Off
CoordMode "Mouse", "Screen"

; This file is intentionally a one-shot sender.  It accepts only x, left,
; and right, and re-checks the session and target immediately before input.

StdOut(text) {
    FileAppend(text "`n", "*")
}

Fail(message) {
    throw Error(message)
}

Tick64() {
    return DllCall("GetTickCount64", "UInt64")
}

RequireBefore(deadline) {
    if (Tick64() > deadline)
        Fail("deadline expired")
}

ParseUnsigned(value, label) {
    if !RegExMatch(value, "^\d+$")
        Fail("invalid " label)
    return Integer(value)
}

NormalizePath(value) {
    return StrLower(StrReplace(value, "/", "\"))
}

ReadSession(token) {
    sessionPath := A_ScriptDir "\session.ini"
    if !FileExist(sessionPath)
        Fail("session.ini missing")
    try {
        active := IniRead(sessionPath, "session", "Active", "")
        current := IniRead(sessionPath, "session", "Token", "")
    } catch as err {
        Fail("session.ini unreadable")
    }
    if (active != "1" || current = "" || !RegExMatch(current, "^[A-Za-z0-9_-]+$"))
        Fail("session inactive")
    if (current != token)
        Fail("session token mismatch")
}

ClientGeometry(hwnd) {
    rect := Buffer(16, 0)
    if !DllCall("GetClientRect", "Ptr", hwnd, "Ptr", rect.Ptr, "Int")
        Fail("GetClientRect failed")
    width := NumGet(rect, 8, "Int") - NumGet(rect, 0, "Int")
    height := NumGet(rect, 12, "Int") - NumGet(rect, 4, "Int")
    if (width <= 0 || height <= 0)
        Fail("invalid client size")

    topLeft := Buffer(8, 0)
    bottomRight := Buffer(8, 0)
    if !DllCall("ClientToScreen", "Ptr", hwnd, "Ptr", topLeft.Ptr, "Int")
        Fail("ClientToScreen failed")
    NumPut("Int", width, bottomRight, 0)
    NumPut("Int", height, bottomRight, 4)
    if !DllCall("ClientToScreen", "Ptr", hwnd, "Ptr", bottomRight.Ptr, "Int")
        Fail("ClientToScreen failed")
    return {
        left: NumGet(topLeft, 0, "Int"),
        top: NumGet(topLeft, 4, "Int"),
        right: NumGet(bottomRight, 0, "Int"),
        bottom: NumGet(bottomRight, 4, "Int"),
        width: width,
        height: height
    }
}

MonitorContains(left, top, right, bottom) {
    count := MonitorGetCount()
    Loop count {
        try {
            MonitorGet(A_Index, &monitorLeft, &monitorTop, &monitorRight, &monitorBottom)
        } catch {
            continue
        }
        if (monitorLeft <= left && monitorTop <= top
            && monitorRight >= right && monitorBottom >= bottom)
            return true
    }
    return false
}

InputDesktopAvailable() {
    desktop := DllCall("OpenInputDesktop", "UInt", 0, "Int", 0,
        "UInt", 0x0100, "Ptr")
    if !desktop
        return false
    DllCall("CloseDesktop", "Ptr", desktop, "Int")
    return true
}

WindowRect(hwnd) {
    rect := Buffer(16, 0)
    if !DllCall("GetWindowRect", "Ptr", hwnd, "Ptr", rect.Ptr, "Int")
        return {ok: false, valid: false}
    value := {
        left: NumGet(rect, 0, "Int"),
        top: NumGet(rect, 4, "Int"),
        right: NumGet(rect, 8, "Int"),
        bottom: NumGet(rect, 12, "Int")
    }
    if (value.right <= value.left || value.bottom <= value.top)
        return {ok: true, valid: false}
    value.ok := true
    value.valid := true
    return value
}

RectsIntersect(first, second) {
    return first.left < second.right && second.left < first.right
        && first.top < second.bottom && second.top < first.bottom
}

WindowIsCloaked(hwnd) {
    cloaked := Buffer(4, 0)
    result := DllCall("dwmapi\DwmGetWindowAttribute", "Ptr", hwnd,
        "UInt", 14, "Ptr", cloaked.Ptr, "UInt", 4, "Int")
    if (result != 0)
        return false
    return NumGet(cloaked, 0, "UInt") != 0
}

FormatRect(rect) {
    if !rect
        return "unknown"
    return "(" rect.left ", " rect.top ", " rect.right ", " rect.bottom ")"
}

WindowDescriptor(hwnd, rectText := "unknown") {
    exe := "<unknown>"
    pid := "unknown"
    try {
        exe := WinGetProcessName("ahk_id " hwnd)
    } catch {
    }
    try {
        pid := WinGetPID("ahk_id " hwnd)
    } catch {
    }
    return "exe=" exe " pid=" pid " hwnd=" hwnd " rect=" rectText
}

OverlayAboveTarget(hwnd, clientGeometry) {
    foundTarget := false
    for candidate in WinGetList() {
        if (candidate = hwnd) {
            foundTarget := true
            break
        }
        if !DllCall("IsWindow", "Ptr", candidate, "Int")
            continue
        if !DllCall("IsWindowVisible", "Ptr", candidate, "Int")
            continue
        if DllCall("IsIconic", "Ptr", candidate, "Int")
            continue
        if WindowIsCloaked(candidate)
            continue
        overlay := WindowRect(candidate)
        if !overlay.ok
            return "GetWindowRect failed; " WindowDescriptor(candidate)
        if !overlay.valid
            continue
        if RectsIntersect(overlay, clientGeometry)
            return "topmost window intersects target; " WindowDescriptor(candidate, FormatRect(overlay))
    }
    if !foundTarget
        return "target is absent from top-level z-order; " WindowDescriptor(hwnd)
    return ""
}

RootWindow(hwnd) {
    root := DllCall("GetAncestor", "Ptr", hwnd, "UInt", 2, "Ptr")
    return root ? root : hwnd
}

ForegroundIs(hwnd) {
    foreground := DllCall("GetForegroundWindow", "Ptr")
    if !foreground
        return false
    return foreground = hwnd || RootWindow(foreground) = hwnd
}

WindowAtBelongs(hwnd, x, y) {
    ; WindowFromPoint takes POINT by value.  Pack two signed 32-bit values in
    ; an Int64 so negative monitor coordinates remain valid.
    packed := ((y & 0xFFFFFFFF) << 32) | (x & 0xFFFFFFFF)
    found := DllCall("WindowFromPoint", "Int64", packed, "Ptr")
    if !found
        return false
    return RootWindow(found) = hwnd
}

SurfaceFailure(hwnd, geometry) {
    if !InputDesktopAvailable()
        return "input desktop unavailable"
    ; The game window may be freely moved and can sit a few pixels beyond a monitor
    ; edge. Keyboard input does not depend on full client visibility; mouse input is
    ; validated at the exact click pixel by VerifyClickPoint().
    return ""
}

SurfaceUnobscured(hwnd, geometry) {
    return SurfaceFailure(hwnd, geometry) = ""
}

UniqueTarget(hwnd, expectedPath) {
    count := 0
    for candidate in WinGetList() {
        if !DllCall("IsWindow", "Ptr", candidate, "Int")
            continue
        if !DllCall("IsWindowVisible", "Ptr", candidate, "Int")
            continue
        if DllCall("IsIconic", "Ptr", candidate, "Int")
            continue
        try {
            if (WinGetTitle("ahk_id " candidate) != "佣兵传说")
                continue
            if (StrLower(WinGetProcessName("ahk_id " candidate)) != "neodark.exe")
                continue
            candidatePath := NormalizePath(WinGetProcessPath("ahk_id " candidate))
        } catch {
            continue
        }
        if (candidatePath != NormalizePath(expectedPath))
            continue
        count += 1
        if (candidate != hwnd)
            Fail("another matching target window exists")
    }
    if (count != 1)
        Fail("target window is not unique")
}

VerifyTarget(hwnd, pid, width, height, expectedPath, deadline) {
    RequireBefore(deadline)
    if !DllCall("IsWindow", "Ptr", hwnd, "Int")
        Fail("target window is gone")
    if !DllCall("IsWindowVisible", "Ptr", hwnd, "Int")
        Fail("target window is hidden")
    if DllCall("IsIconic", "Ptr", hwnd, "Int")
        Fail("target window is minimized")
    if (WinGetTitle("ahk_id " hwnd) != "佣兵传说")
        Fail("target title changed")
    if (WinGetPID("ahk_id " hwnd) != pid)
        Fail("target pid changed")
    if (StrLower(WinGetProcessName("ahk_id " hwnd)) != "neodark.exe")
        Fail("target process changed")
    if (NormalizePath(WinGetProcessPath("ahk_id " hwnd)) != NormalizePath(expectedPath))
        Fail("target executable path changed")
    if !ForegroundIs(hwnd)
        Fail("target is not foreground")
    UniqueTarget(hwnd, expectedPath)
    geometry := ClientGeometry(hwnd)
    if (geometry.width != width || geometry.height != height)
        Fail("target client size changed")
    failureText := SurfaceFailure(hwnd, geometry)
    if (failureText != "")
        Fail(failureText)
    return geometry
}

VerifyClickPoint(hwnd, geometry, x, y) {
    if (x < 0 || y < 0 || x >= geometry.width || y >= geometry.height)
        Fail("click point outside client")
    screenPoint := Buffer(8, 0)
    NumPut("Int", x, screenPoint, 0)
    NumPut("Int", y, screenPoint, 4)
    if !DllCall("ClientToScreen", "Ptr", hwnd, "Ptr", screenPoint.Ptr, "Int")
        Fail("click ClientToScreen failed")
    screenX := NumGet(screenPoint, 0, "Int")
    screenY := NumGet(screenPoint, 4, "Int")
    if !MonitorContains(screenX, screenY, screenX + 1, screenY + 1)
        Fail("click point outside monitor")
    if !WindowAtBelongs(hwnd, screenX, screenY)
        Fail("click point is covered")
    return [screenX, screenY]
}

Perform(action, hwnd, pid, width, height, token, deadline, xArg, yArg, expectedPath) {
    RequireBefore(deadline)
    ReadSession(token)
    geometry := VerifyTarget(hwnd, pid, width, height, expectedPath, deadline)
    RequireBefore(deadline)
    if (action = "x" || action = "tab") {
        if (xArg != "" || yArg != "")
            Fail(action " action has unexpected coordinates")
        ; Final session read before keyboard input. Always release the key.
        ReadSession(token)
        keyName := action = "x" ? "x" : "Tab"
        try {
            SendEvent("{" keyName " down}")
            Sleep(40)
        } finally {
            SendEvent("{" keyName " up}")
        }
        return
    }

    x := ParseUnsigned(xArg, "x")
    y := ParseUnsigned(yArg, "y")
    screenPoint := VerifyClickPoint(hwnd, geometry, x, y)
    RequireBefore(deadline)
    ReadSession(token)
    geometry := VerifyTarget(hwnd, pid, width, height, expectedPath, deadline)
    ; Recompute the screen point after the final target check so a window move
    ; between validation and conversion cannot reuse stale coordinates.
    screenPoint := VerifyClickPoint(hwnd, geometry, x, y)
    RequireBefore(deadline)
    ReadSession(token)
    Click(screenPoint[1], screenPoint[2], action = "left" ? "Left" : "Right", 1)
}

Main() {
    if (A_Args.Length = 1 && A_Args[1] = "--selftest") {
        StdOut("sender.ahk AutoHotkey " A_AhkVersion)
        return
    }
    if (A_Args.Length < 10)
        Fail("usage: action hwnd pid width height token deadline x y expectedPath")

    action := StrLower(A_Args[1])
    if (action != "tab" && action != "x" && action != "left" && action != "right")
        Fail("action is not allowed")
    hwnd := ParseUnsigned(A_Args[2], "hwnd")
    pid := ParseUnsigned(A_Args[3], "pid")
    width := ParseUnsigned(A_Args[4], "width")
    height := ParseUnsigned(A_Args[5], "height")
    token := A_Args[6]
    if !RegExMatch(token, "^[A-Za-z0-9_-]+$")
        Fail("invalid token")
    observationDeadline := ParseUnsigned(A_Args[7], "observation deadline")
    deadline := observationDeadline
    shortDeadline := Tick64() + 900
    if (shortDeadline < deadline)
        deadline := shortDeadline
    xArg := A_Args[8]
    yArg := A_Args[9]
    expectedPath := A_Args[10]
    if (expectedPath = "")
        Fail("missing executable path")
    Perform(action, hwnd, pid, width, height, token, deadline, xArg, yArg, expectedPath)
}

try {
    Main()
    ExitApp(0)
} catch as err {
    StdOut("ERROR: " err.Message)
    ExitApp(2)
}
