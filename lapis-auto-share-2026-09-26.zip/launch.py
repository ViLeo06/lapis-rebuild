"""Visible launcher error reporting. Never starts a training session itself."""
from pathlib import Path
import runpy
import sys
import traceback

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))

if __name__ == "__main__":
    try:
        # DPI awareness must be configured before Tk creates its first window.
        # Otherwise Win32 returns logical 1066x800 coordinates while ImageGrab
        # and AutoHotkey use physical 1600x1200 pixels on the user's 150% display.
        import winbridge
        winbridge._configure_dpi_awareness()
        runpy.run_path(str(BASE / "app.py"), run_name="__main__")
    except Exception:
        details = traceback.format_exc()
        try:
            (BASE / "launcher-error.log").write_text(details, encoding="utf-8")
        except OSError:
            pass
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(
            "练级工具未启动",
            "程序未能启动，没有开始练级。\n\n"
            "请把本目录 launcher-error.log 的内容交给 Codex 检查。\n"
            "不要重复安装或修改游戏。\n\n" + details.splitlines()[-1],
            parent=root,
        )
        root.destroy()
        raise SystemExit(1)
