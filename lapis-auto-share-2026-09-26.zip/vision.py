"""基于录像参考帧的只读画面识别。

识别只处理 Bridge.capture() 返回的当前游戏截图，不读取窗口外桌面，不联网。
模板来自 assets 中的代表帧；holdout 只用于测试，不在运行时作为模板加载。
健康值是 HUD 颜色条的保守估计，无法解释时返回 None，交给状态机安全停机。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

import cv2
import numpy as np
from PIL import Image

try:
    from .engine import Observation, Scene
except ImportError:  # 直接 python vision.py / app.py 时使用
    from engine import Observation, Scene


NORMALIZED_SIZE = (1024, 768)
SOURCE_TITLE_HEIGHT = 27
REFERENCE_SOURCE_SIZE = (1572, 1208)

# 所有坐标都是裁掉标题栏、缩放为 1024x768 后的 client 坐标。
ROIS: dict[str, tuple[int, int, int, int]] = {
    "battle_banner": (8, 18, 200, 65),
    "victory": (180, 170, 850, 390),
    "inventory": (575, 20, 950, 710),
    "field_nav": (210, 0, 780, 45),
    "portraits": (850, 20, 1024, 580),
    "range": (220, 220, 830, 580),
    "effect": (300, 250, 700, 580),
}


@dataclass(frozen=True)
class VisionObservation:
    scene: Scene
    range_ready: bool = False
    poison_effect: bool = False
    hp_ratio: float | None = None
    mp_ratio: float | None = None
    frame_shape: tuple[int, int] = (0, 0)
    confidence: float = 0.0
    scores: dict[str, float] = field(default_factory=dict)
    notes: tuple[str, ...] = ()

    def to_engine(
        self,
        frame_id: int,
        *,
        observed_at: float | None = None,
        observation_deadline: float | None = None,
        observation_deadline_tick: int | None = None,
    ) -> Observation:
        return Observation(
            scene=self.scene,
            frame_id=frame_id,
            range_ready=self.range_ready,
            poison_effect=self.poison_effect,
            hp_ratio=self.hp_ratio,
            mp_ratio=self.mp_ratio,
            observation_deadline=observation_deadline,
            observation_deadline_tick=observation_deadline_tick,
        )


class Vision:
    """固定 1572x1208 客户端布局的谨慎模板识别器。"""

    def __init__(self, assets_dir: str | Path):
        # 分享版不携带用户录屏提取出的整帧模板，避免把个人运行画面打包出去。
        # 当前稳定识别路径依赖固定 UI 颜色/布局特征（FIELD/BATTLE/VICTORY）；
        # legacy 模板分数保留为 0，仅作为兼容字段存在。
        self.assets_dir = Path(assets_dir).resolve()
        self._templates: dict[str, np.ndarray] = {}
        self.last_scores: dict[str, float] = {}

    @staticmethod
    def normalize(image: Image.Image | np.ndarray) -> np.ndarray:
        """裁掉原客户端 27px 标题栏并统一到 1024x768 RGB。"""

        if isinstance(image, Image.Image):
            arr = np.asarray(image.convert("RGB"))
        else:
            arr = np.asarray(image)
            if arr.ndim == 2:
                arr = cv2.cvtColor(arr, cv2.COLOR_GRAY2RGB)
            elif arr.ndim == 3 and arr.shape[2] == 4:
                arr = cv2.cvtColor(arr, cv2.COLOR_RGBA2RGB)
            elif arr.ndim != 3 or arr.shape[2] != 3:
                raise ValueError("截图必须是 RGB/RGBA/灰度图")
            # ndarray 默认约定为 RGB，Bridge 返回的 PIL 图像同样先转 RGB。
        # 录像参考帧包含 27px 标题栏；Bridge.capture() 返回的是客户区，
        # 不能再次裁标题栏。旧逻辑按“大于某尺寸”判断，导致 1600x1200
        # 的实时客户区也被误裁 27px，所有固定 ROI 因而整体错位。
        if (arr.shape[1], arr.shape[0]) == REFERENCE_SOURCE_SIZE:
            arr = arr[SOURCE_TITLE_HEIGHT:, :, :]
        if arr.shape[0] < 200 or arr.shape[1] < 300:
            raise ValueError(f"截图尺寸过小: {arr.shape}")
        return cv2.resize(arr, NORMALIZED_SIZE, interpolation=cv2.INTER_AREA)

    @staticmethod
    def _gray_roi(frame: np.ndarray, roi: tuple[int, int, int, int]) -> np.ndarray:
        x1, y1, x2, y2 = roi
        return cv2.cvtColor(frame[y1:y2, x1:x2], cv2.COLOR_RGB2GRAY)

    def _score(self, frame_gray: np.ndarray, template_name: str, roi_name: str) -> float:
        template_frame = self._templates.get(template_name)
        if template_frame is None:
            return 0.0
        roi = ROIS[roi_name]
        current = self._gray_roi(cv2.cvtColor(frame_gray, cv2.COLOR_GRAY2RGB), roi)
        template = template_frame[roi[1] : roi[3], roi[0] : roi[2]]
        if current.shape != template.shape:
            return 0.0
        result = cv2.matchTemplate(current, template, cv2.TM_CCOEFF_NORMED)
        value = float(result[0, 0])
        return value if np.isfinite(value) else 0.0

    def _score_gray(self, frame_gray: np.ndarray, template_name: str, roi_name: str) -> float:
        template_frame = self._templates.get(template_name)
        if template_frame is None:
            return 0.0
        x1, y1, x2, y2 = ROIS[roi_name]
        current = frame_gray[y1:y2, x1:x2]
        template = template_frame[y1:y2, x1:x2]
        result = cv2.matchTemplate(current, template, cv2.TM_CCOEFF_NORMED)
        value = float(result[0, 0])
        return value if np.isfinite(value) else 0.0

    @staticmethod
    def _longest_run(mask: np.ndarray) -> int:
        best = run = 0
        for value in mask.astype(bool).tolist():
            run = run + 1 if value else 0
            best = max(best, run)
        return best

    @classmethod
    def _bar_ratio(
        cls,
        frame: np.ndarray,
        y1: int,
        y2: int,
        kind: str,
    ) -> tuple[float | None, float]:
        """Estimate the current player-server HP/MP bar fill.

        The live 1600x1200 client places the bar body at normalized x=914..1022.
        Large white numeric labels cut through some rows, so using a median of long
        runs (the old implementation) under-counted or completely lost the MP bar.
        The longest clean row is much more stable here and is still constrained to
        the tiny HUD strip, so field/victory frames do not produce a valid bar.
        """

        rgb = frame[y1:y2, 914:1023].astype(np.int16)
        r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
        if kind == "hp":
            mask = (r > 35) & (r > g * 1.5) & (r > b * 1.3) & (g < 70)
        else:
            # MP is a dark navy bar on this server, not the bright blue used by
            # the old reference frame.
            mask = (b > 35) & (b > r * 1.30) & (b > g * 1.15) & (r < 75) & (g < 75)
        lengths = np.asarray([cls._longest_run(row) for row in mask], dtype=np.float32)
        best = float(lengths.max(initial=0.0))
        if best < 12:
            return None, 0.0
        near = int((lengths >= max(12.0, best * 0.70)).sum())
        minimum_rows = 3 if kind == "hp" else 2
        if near < minimum_rows:
            return None, min(0.3, near / max(1, minimum_rows))
        # Live bar body is about 104 normalized pixels wide.
        ratio = max(0.0, min(1.0, best / 104.0))
        confidence = max(0.45, min(1.0, near / 4.0))
        return ratio, confidence

    @staticmethod
    def _scene_signatures(frame: np.ndarray) -> dict[str, float]:
        """Stable UI signatures for field/battle/victory on the current server.

        These deliberately avoid map/background matching. Window movement does not
        matter because Bridge captures client coordinates and the frame is normalized.
        """

        hsv = cv2.cvtColor(frame, cv2.COLOR_RGB2HSV)

        # Field: the right side contains four large ornate gold portrait rings.
        right = hsv[0:650, 820:1024]
        gold = (
            (right[:, :, 0] >= 15)
            & (right[:, :, 0] <= 35)
            & (right[:, :, 1] > 80)
            & (right[:, :, 2] > 120)
        )
        field_portrait_gold = float(gold.mean())

        # Victory: giant blue/purple VICTORY letters fill the central band.
        center = hsv[120:380, 120:900]
        purple = (
            (center[:, :, 0] >= 115)
            & (center[:, :, 0] <= 165)
            & (center[:, :, 1] > 100)
            & (center[:, :, 2] > 80)
        )
        victory_purple = float(purple.mean())

        # Result screen: the current player server shows a bright gold/white
        # reward panel at top-center ("金币 / 怪物") after combat, sometimes
        # without the legacy giant VICTORY word.
        reward = hsv[0:110, 300:650]
        reward_gold = (
            (reward[:, :, 0] >= 12)
            & (reward[:, :, 0] <= 35)
            & (reward[:, :, 1] > 100)
            & (reward[:, :, 2] > 130)
        )
        reward_white = (reward[:, :, 1] < 50) & (reward[:, :, 2] > 180)
        result_reward_gold = float(reward_gold.mean())
        result_reward_white = float(reward_white.mean())

        # Battle: compact top-right combat HUD contains a red HP bar. The actual
        # HP/MP readers below are stronger evidence when both can be decoded.
        top_right = hsv[0:100, 850:1024]
        red = (
            ((top_right[:, :, 0] < 10) | (top_right[:, :, 0] > 170))
            & (top_right[:, :, 1] > 120)
            & (top_right[:, :, 2] > 100)
        )
        battle_red = float(red.mean())

        return {
            "field_portrait_gold": field_portrait_gold,
            "victory_purple": victory_purple,
            "result_reward_gold": result_reward_gold,
            "result_reward_white": result_reward_white,
            "battle_red": battle_red,
        }

    @staticmethod
    def _orange_grid_evidence(frame: np.ndarray) -> tuple[bool, int]:
        """要求中央外围出现大面积橙色网格线，排除脚下小范围特效。"""

        hsv = cv2.cvtColor(frame[240:580, 220:830], cv2.COLOR_RGB2HSV)
        mask = (
            (hsv[:, :, 0] >= 4)
            & (hsv[:, :, 0] <= 28)
            & (hsv[:, :, 1] > 100)
            & (hsv[:, :, 2] > 90)
        )
        rows = int((mask.sum(axis=1) > 30).sum())
        cols = int((mask.sum(axis=0) > 30).sum())
        count = int(mask.sum())
        return count >= 40000 and rows >= 250 and cols >= 450, count

    @staticmethod
    def _poison_color_evidence(frame: np.ndarray) -> tuple[bool, int]:
        """检测人物周围的高饱和亮绿色，仅作为模板的第二个证据。"""

        hsv = cv2.cvtColor(frame[380:620, 430:700], cv2.COLOR_RGB2HSV)
        mask = (
            (hsv[:, :, 0] >= 35)
            & (hsv[:, :, 0] <= 95)
            & (hsv[:, :, 1] > 180)
            & (hsv[:, :, 2] > 160)
        )
        count = int(mask.sum())
        return count >= 500, count

    def analyze(self, image: Image.Image | np.ndarray) -> VisionObservation:
        frame = self.normalize(image)
        gray = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
        scores = {
            "victory": self._score_gray(gray, "victory", "victory"),
            "inventory": self._score_gray(gray, "inventory", "inventory"),
            "battle": self._score_gray(gray, "battle", "battle_banner"),
            "field_nav": self._score_gray(gray, "field", "field_nav"),
            "portraits": self._score_gray(gray, "field", "portraits"),
            "range": self._score_gray(gray, "range", "range"),
            "effect": self._score_gray(gray, "effect", "effect"),
        }
        signatures = self._scene_signatures(frame)
        scores.update(signatures)
        self.last_scores = scores

        # Current live HUD positions after titlebar-free client capture.
        hp_probe, hp_probe_conf = self._bar_ratio(frame, 14, 25, "hp")
        mp_probe, mp_probe_conf = self._bar_ratio(frame, 32, 43, "mp")
        battle_hud = hp_probe is not None and mp_probe is not None
        victory_signature = signatures["victory_purple"] >= 0.015
        field_signature = signatures["field_portrait_gold"] >= 0.055
        battle_signature = battle_hud or signatures["battle_red"] >= 0.006
        result_signature = (
            not battle_hud
            and not field_signature
            and signatures["result_reward_gold"] >= 0.12
            and signatures["result_reward_white"] >= 0.025
        )

        # Prefer stable UI signatures over whole-map template correlation.
        # 当前玩家服战斗结束不会出现旧录像中的大号 VICTORY，而是短暂显示
        # “金币 / 怪物数量”结算画面。该画面仍保留战斗框架特征，但 HP/MP HUD
        # 已消失，且野外导航/队伍头像尚未恢复。
        live_result = (
            not battle_hud
            and 0.25 <= scores["battle"] < 0.60
            and scores["field_nav"] < 0.12
            and scores["portraits"] < 0.12
        )
        if victory_signature or result_signature or scores["victory"] >= 0.55 or live_result:
            scene = Scene.VICTORY
        elif scores["inventory"] >= 0.55:
            scene = Scene.INVENTORY
        elif battle_signature:
            scene = Scene.BATTLE
        elif field_signature:
            scene = Scene.FIELD
        else:
            # Legacy templates remain as low-priority fallbacks for other maps.
            battle_evidence = (
                scores["battle"] >= 0.55
                or scores["range"] >= 0.55
                or scores["effect"] >= 0.70
            )
            field_evidence = (
                scores["field_nav"] >= 0.16
                and scores["portraits"] >= 0.18
            )
            if battle_evidence and not field_evidence:
                scene = Scene.BATTLE
            elif field_evidence:
                scene = Scene.FIELD
            else:
                scene = Scene.UNKNOWN

        hp_ratio = mp_ratio = None
        hp_conf = mp_conf = 0.0
        if scene == Scene.BATTLE:
            hp_ratio, hp_conf = hp_probe, hp_probe_conf
            mp_ratio, mp_conf = mp_probe, mp_probe_conf
        orange_grid, orange_pixels = self._orange_grid_evidence(frame) if scene == Scene.BATTLE else (False, 0)
        poison_green, green_pixels = self._poison_color_evidence(frame) if scene == Scene.BATTLE else (False, 0)
        # 分享版不携带个人录屏模板；当前 engine 的稳定流程按固定时序
        # Tab -> X -> 左键 -> 左键推进，不依赖 range/effect 模板。
        range_ready = False
        poison_effect = False
        confidence = max(
            0.0,
            min(
                1.0,
                {
                    Scene.VICTORY: max(
                        scores["victory"],
                        scores["battle"] if live_result else 0.0,
                        min(1.0, signatures["victory_purple"] / 0.05) if victory_signature else 0.0,
                        min(1.0, signatures["result_reward_white"] / 0.04) if result_signature else 0.0,
                    ),
                    Scene.INVENTORY: scores["inventory"],
                    Scene.BATTLE: max(
                        scores["battle"],
                        min(hp_probe_conf, mp_probe_conf) if battle_hud else 0.0,
                        min(1.0, signatures["battle_red"] / 0.012) if battle_signature else 0.0,
                    ),
                    Scene.FIELD: max(
                        min(scores["field_nav"], scores["portraits"]),
                        min(1.0, signatures["field_portrait_gold"] / 0.08) if field_signature else 0.0,
                    ),
                    Scene.UNKNOWN: 0.0,
                }[scene],
            ),
        )
        notes: list[str] = []
        if scene == Scene.VICTORY and victory_signature:
            notes.append("检测到中央 VICTORY 蓝紫色大字")
        elif scene == Scene.VICTORY and result_signature:
            notes.append("检测到玩家服金币/怪物战后结算面板")
        elif scene == Scene.VICTORY and live_result:
            notes.append("检测到玩家服战后结算画面")
        if scene == Scene.FIELD and field_signature:
            notes.append(f"检测到野外右侧队伍头像栏（gold={signatures['field_portrait_gold']:.3f}）")
        if scene == Scene.UNKNOWN:
            notes.append(
                "识别分数 "
                f"field_nav={scores['field_nav']:.2f} portraits={scores['portraits']:.2f} "
                f"battle={scores['battle']:.2f} victory={scores['victory']:.2f} "
                f"gold={signatures['field_portrait_gold']:.3f} "
                f"purple={signatures['victory_purple']:.3f} red={signatures['battle_red']:.3f}"
            )
        if scene == Scene.BATTLE:
            notes.append("HP/MP 为固定 HUD 颜色条的视觉估计，需下一帧核验")
            if hp_ratio is None or mp_ratio is None:
                notes.append("血蓝条读数不可解释")
            else:
                notes.append(f"HUD estimate hp={hp_ratio:.2f} mp={mp_ratio:.2f}")
            if poison_effect:
                notes.append("检测到绿色毒效模板")
            if range_ready:
                notes.append("检测到橙色施法范围模板")
            if scores["range"] >= 0.82 and not orange_grid:
                notes.append(f"橙色网格辅助证据不足（{orange_pixels}像素）")
            if scores["effect"] >= 0.90 and not poison_green:
                notes.append(f"绿色毒效辅助证据不足（{green_pixels}像素）")
        return VisionObservation(
            scene=scene,
            range_ready=range_ready,
            poison_effect=poison_effect,
            hp_ratio=hp_ratio,
            mp_ratio=mp_ratio,
            frame_shape=(int(frame.shape[1]), int(frame.shape[0])),
            confidence=confidence,
            scores=scores,
            notes=tuple(notes),
        )


def replay_directory(vision: Vision, directory: str | Path) -> list[VisionObservation]:
    """纯只读回放识别；不会创建 Bridge，也不会发送输入。"""

    root = Path(directory)
    result: list[VisionObservation] = []
    for path in sorted(root.glob("*.png")):
        with Image.open(path) as image:
            result.append(vision.analyze(image))
    return result


__all__ = ["NORMALIZED_SIZE", "ROIS", "Vision", "VisionObservation", "replay_directory"]
