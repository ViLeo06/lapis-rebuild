"""Observability-only diagnostics for lapis-auto.

This module must never decide game actions. It only records session metadata,
event JSONL, periodic screenshots, and stop/error evidence for later debugging.
"""

from __future__ import annotations

from dataclasses import asdict, is_dataclass
import json
import os
from pathlib import Path
import shutil
import time
from typing import Any


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if is_dataclass(value):
        return _jsonable(asdict(value))
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(v) for v in value]
    item = getattr(value, "item", None)
    if callable(item):
        try:
            return _jsonable(item())
        except Exception:
            pass
    return str(value)


class DiagnosticsRecorder:
    """Append-only session diagnostics with bounded local retention."""

    def __init__(
        self,
        log_dir: str | Path,
        *,
        snapshot_interval_seconds: float = 600.0,
        max_sessions: int = 60,
    ) -> None:
        self.log_dir = Path(log_dir).resolve()
        self.sessions_dir = self.log_dir / "sessions"
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.snapshot_interval_seconds = float(snapshot_interval_seconds)
        self.max_sessions = int(max_sessions)
        self.session_id: str | None = None
        self.session_dir: Path | None = None
        self.events_path: Path | None = None
        self.started_wall: float | None = None
        self.started_monotonic: float | None = None
        self.next_snapshot_monotonic: float | None = None

    @property
    def active(self) -> bool:
        return self.session_dir is not None and self.session_id is not None

    def start_session(
        self,
        *,
        mode: str,
        bound: dict[str, Any] | None,
        positions: Any,
        config: Any,
        image: Any | None = None,
        context: dict[str, Any] | None = None,
    ) -> str:
        if self.active:
            self.stop_session(
                "diagnostics session replaced",
                image=None,
                context=context,
                abnormal=False,
            )

        wall = time.time()
        stamp = time.strftime("%Y%m%d-%H%M%S", time.localtime(wall))
        safe_mode = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in mode)[:24] or "session"
        session_id = f"{stamp}-{safe_mode}-p{os.getpid()}"
        session_dir = self.sessions_dir / session_id
        suffix = 1
        while session_dir.exists():
            suffix += 1
            session_dir = self.sessions_dir / f"{session_id}-{suffix}"
        session_dir.mkdir(parents=True)
        (session_dir / "screenshots").mkdir()

        self.session_id = session_dir.name
        self.session_dir = session_dir
        self.events_path = session_dir / "events.jsonl"
        self.started_wall = wall
        self.started_monotonic = time.monotonic()
        self.next_snapshot_monotonic = self.started_monotonic + self.snapshot_interval_seconds

        metadata = {
            "schema": 1,
            "session_id": self.session_id,
            "started_at": time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime(wall)),
            "mode": mode,
            "bound": _jsonable(bound),
            "positions": _jsonable(positions),
            "config": _jsonable(config),
            "snapshot_interval_seconds": self.snapshot_interval_seconds,
        }
        self._write_json(session_dir / "metadata.json", metadata)
        self.record_event("session_start", mode=mode, context=context or {})
        if image is not None:
            self.save_snapshot("start", image, context=context or {})
        self._prune_old_sessions()
        return self.session_id

    def record_event(self, event: str, **data: Any) -> None:
        if not self.active or self.events_path is None:
            return
        payload = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "wall_time": time.time(),
            "event": event,
            **{k: _jsonable(v) for k, v in data.items()},
        }
        try:
            with self.events_path.open("a", encoding="utf-8", newline="\n") as handle:
                handle.write(json.dumps(payload, ensure_ascii=False, sort_keys=True))
                handle.write("\n")
                handle.flush()
        except OSError:
            return

    def maybe_periodic_snapshot(
        self,
        image: Any | None,
        *,
        now_monotonic: float | None = None,
        context: dict[str, Any] | None = None,
    ) -> Path | None:
        if not self.active or image is None or self.next_snapshot_monotonic is None:
            return None
        now = time.monotonic() if now_monotonic is None else float(now_monotonic)
        if now < self.next_snapshot_monotonic:
            return None
        while self.next_snapshot_monotonic <= now:
            self.next_snapshot_monotonic += self.snapshot_interval_seconds
        path = self.save_snapshot("periodic", image, context=context or {})
        if path is not None:
            self.record_event("periodic_snapshot", path=path.name, context=context or {})
        return path

    def save_snapshot(
        self,
        kind: str,
        image: Any | None,
        *,
        context: dict[str, Any] | None = None,
    ) -> Path | None:
        if not self.active or self.session_dir is None or image is None:
            return None
        stamp = time.strftime("%Y%m%d-%H%M%S")
        millis = int((time.time() % 1) * 1000)
        safe_kind = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in kind)[:32] or "frame"
        stem = f"{stamp}-{millis:03d}-{safe_kind}"
        shot_dir = self.session_dir / "screenshots"
        path = shot_dir / f"{stem}.jpg"
        temp = shot_dir / f".{stem}.tmp"
        try:
            frame = image.convert("RGB") if getattr(image, "mode", "RGB") != "RGB" else image
            frame.save(temp, format="JPEG", quality=82, subsampling=0)
            os.replace(temp, path)
            sidecar = {
                "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                "kind": kind,
                "image": path.name,
                "context": _jsonable(context or {}),
            }
            self._write_json(shot_dir / f"{stem}.json", sidecar)
            return path
        except Exception:
            try:
                temp.unlink(missing_ok=True)
            except Exception:
                pass
            return None

    def stop_session(
        self,
        reason: str,
        *,
        image: Any | None,
        context: dict[str, Any] | None = None,
        abnormal: bool,
    ) -> None:
        if not self.active or self.session_dir is None:
            return
        session_dir = self.session_dir
        elapsed = None
        if self.started_monotonic is not None:
            elapsed = max(0.0, time.monotonic() - self.started_monotonic)
        self.record_event(
            "session_stop",
            reason=reason,
            abnormal=abnormal,
            elapsed_seconds=elapsed,
            context=context or {},
        )
        kind = "abnormal-stop" if abnormal else "stop"
        snapshot = self.save_snapshot(kind, image, context=context or {}) if image is not None else None
        summary = {
            "schema": 1,
            "session_id": self.session_id,
            "ended_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "reason": reason,
            "abnormal": abnormal,
            "elapsed_seconds": elapsed,
            "final_snapshot": snapshot.name if snapshot is not None else None,
            "context": _jsonable(context or {}),
        }
        self._write_json(session_dir / "summary.json", summary)
        self.session_id = None
        self.session_dir = None
        self.events_path = None
        self.started_wall = None
        self.started_monotonic = None
        self.next_snapshot_monotonic = None

    @staticmethod
    def _write_json(path: Path, payload: dict[str, Any]) -> None:
        temp = path.with_name(f".{path.name}.tmp")
        try:
            with temp.open("w", encoding="utf-8", newline="\n") as handle:
                json.dump(_jsonable(payload), handle, ensure_ascii=False, indent=2, sort_keys=True)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp, path)
        except OSError:
            try:
                temp.unlink(missing_ok=True)
            except Exception:
                pass

    def _prune_old_sessions(self) -> None:
        if self.max_sessions <= 0:
            return
        try:
            dirs = sorted(
                (p for p in self.sessions_dir.iterdir() if p.is_dir()),
                key=lambda p: p.stat().st_mtime,
                reverse=True,
            )
        except OSError:
            return
        for old in dirs[self.max_sessions :]:
            if self.session_dir is not None and old == self.session_dir:
                continue
            try:
                shutil.rmtree(old)
            except OSError:
                pass


__all__ = ["DiagnosticsRecorder"]
