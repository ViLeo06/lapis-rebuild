@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo === 佣兵传说练级工具：安装依赖 ===

where py >nul 2>nul
if %errorlevel%==0 (
  set "PYTHON_CMD=py -3"
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    set "PYTHON_CMD=python"
  ) else (
    echo [错误] 未找到 Python。
    echo 请先安装 64 位 Python 3.11~3.13，并勾选 Add Python to PATH。
    pause
    exit /b 1
  )
)

if not exist ".venv\Scripts\python.exe" (
  echo [1/3] 创建本地虚拟环境...
  %PYTHON_CMD% -m venv .venv
  if errorlevel 1 goto :fail
) else (
  echo [1/3] 已存在 .venv，跳过创建。
)

echo [2/3] 安装 Python 依赖...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :fail
".venv\Scripts\python.exe" -m pip install -r requirements.lock.txt
if errorlevel 1 goto :fail

echo [3/3] 检查 AutoHotkey v2...
set "AHK_OK="
if exist "%LOCALAPPDATA%\Programs\AutoHotkey\v2\AutoHotkey64.exe" set "AHK_OK=1"
if exist "%ProgramFiles%\AutoHotkey\v2\AutoHotkey64.exe" set "AHK_OK=1"
if exist "%ProgramFiles(x86)%\AutoHotkey\v2\AutoHotkey64.exe" set "AHK_OK=1"

if not defined AHK_OK (
  echo.
  echo [提醒] 没有在常见位置找到 AutoHotkey64.exe。
  echo 请安装 AutoHotkey v2 64 位后再启动工具。
  echo 工具本身还会在启动时继续搜索其他常见安装位置。
) else (
  echo AutoHotkey v2 已检测到。
)

echo.
echo 安装完成。以后双击“启动练级工具.bat”即可。
pause
exit /b 0

:fail
echo.
echo [错误] 安装失败。请保留当前窗口中的报错信息。
pause
exit /b 1
